#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
TRACKER_PUBLIC_DATA="${SHOPEE_TRACKER_DATA:-$HOME/Library/Application Support/ShopeeTrackerPublic}"
TRACKER_PUBLIC_PY="$TRACKER_PUBLIC_DATA/venv/bin/python"
if [ ! -x "$TRACKER_PUBLIC_PY" ]; then bash tool/Setup.command; fi
export SHOPEE_TRACKER_DATA="$TRACKER_PUBLIC_DATA"
exec "$TRACKER_PUBLIC_PY" mac/app_launcher.py
