See ../README.md. build.sh creates an isolated Shopee Tracker Public.app with no private defaults.
