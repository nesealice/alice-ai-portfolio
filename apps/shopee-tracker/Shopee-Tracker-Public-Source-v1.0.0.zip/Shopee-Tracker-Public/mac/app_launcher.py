"""Local-only macOS launcher. No AI dependencies or bundled credentials."""
import hmac,json,os,secrets,shutil,subprocess,sys,threading,webbrowser,queue,fcntl,time
from contextlib import redirect_stdout,redirect_stderr
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from urllib.request import Request,urlopen

RESOURCE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]/'tool'))
DATA=Path(os.environ.get('SHOPEE_TRACKER_DATA',str(Path.home()/'Library'/'Application Support'/'ShopeeTrackerPublic'))).expanduser().resolve()
SERVICE='com.local.shopeetracker.public.feishu'

def public_config(config):
    return {k:v for k,v in config.items() if 'secret' not in k.lower() and 'password' not in k.lower() and k.lower() not in ('access_token','refresh_token','tenant_access_token')}

def authorized(cookie,token):
    try:
        parsed=SimpleCookie();parsed.load(cookie)
        value=parsed.get('tracker_session')
        return bool(value and hmac.compare_digest(value.value,token))
    except Exception:return False

def build_arguments(action,data,options):
    base=['--data-dir',str(data)]
    commands={'login':['login'],'collect':['daily','--config',str(data/'base-config.json')],'resume':['resume','--non-interactive','--config',str(data/'base-config.json')],
      'status':['status'],'writeback':['writeback','--config',str(data/'base-config.json')],
      'preview':['writeback','--preview','--config',str(data/'base-config.json')],
      'export':['export','--output',str(data/'exports'/'latest')],
      'schedule':['schedule','--at','10:00','--config',str(data/'base-config.json')]}
    if action not in commands:raise ValueError('Unknown action')
    return base+commands[action]

def keychain_read(account):
    p=subprocess.run(['/usr/bin/security','find-generic-password','-s',SERVICE,'-a',account,'-w'],capture_output=True,text=True)
    return p.stdout.strip() if p.returncode==0 else ''

def configure():
    DATA.mkdir(parents=True,exist_ok=True);os.chmod(DATA,0o700)
    conf=DATA/'base-config.json'
    if not (DATA/'targets.csv').exists():
        (DATA/'targets.csv').write_text('country,affiliate_id,shopee_handle,url,category,tts_link\n')
    if not conf.exists() and (RESOURCE/'base-config.json').exists():
        conf.write_text(json.dumps(public_config(json.loads((RESOURCE/'base-config.json').read_text())),ensure_ascii=False,indent=2));os.chmod(conf,0o600)
    bundled=RESOURCE/'browser-bundle'
    if bundled.exists():os.environ['PLAYWRIGHT_BROWSERS_PATH']=str(bundled)
    for key in ('FEISHU_APP_ID','FEISHU_APP_SECRET'):
        if not os.environ.get(key):
            value=keychain_read(key)
            if value:os.environ[key]=value
    if str(RESOURCE) not in sys.path:sys.path.insert(0,str(RESOURCE))

HTML=(RESOURCE/'ui.html').read_text(encoding='utf-8')

class ServiceLease:
    """A process lock covers the entire worker/browser lifetime."""
    def __init__(self,data):self.data=Path(data);self.acquired=False
    def __enter__(self):
        self.data.mkdir(parents=True,exist_ok=True);os.chmod(self.data,0o700)
        self.stream=(self.data/'service.lock').open('a');os.chmod(self.data/'service.lock',0o600)
        try:fcntl.flock(self.stream,fcntl.LOCK_EX|fcntl.LOCK_NB);self.acquired=True
        except BlockingIOError:pass
        return self
    def publish(self,url):
        from shopee_tracker.schedule import private_json
        if not self.acquired:raise RuntimeError('Service lock required')
        private_json(self.data/'service.json',{'url':url,'pid':os.getpid()})
    def __exit__(self,*args):
        if self.acquired:
            (self.data/'service.json').unlink(missing_ok=True)
            fcntl.flock(self.stream,fcntl.LOCK_UN)
        self.stream.close()


def existing_service(data):
    try:
        url=json.loads((Path(data)/'service.json').read_text())['url']
        parsed=urlparse(url);token=parse_qs(parsed.query).get('token',[''])[0]
        if parsed.scheme!='http' or parsed.hostname!='127.0.0.1' or not parsed.port or not token:return None
        request=Request(f'http://127.0.0.1:{parsed.port}/state',headers={'Cookie':'tracker_session='+token})
        with urlopen(request,timeout=1) as response:
            return url if response.status==200 else None
    except (OSError,ValueError,KeyError):return None


def notify_auth_needed():
    try:
        subprocess.Popen(['/usr/bin/osascript','-e',
            'display notification "请打开 Shopee Tracker 处理登录或权限问题。已保存的数据仍保留。" with title "Shopee Tracker 需要处理登录或权限"'],
            stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except OSError:pass


class ResidentJobs:
    def __init__(self,data):
        from shopee_tracker.schedule import DailySchedule
        self.data=Path(data);self.schedule=DailySchedule(data)
        self.state={'running':False,'message':'就绪','log':''}
        self.lock=threading.Lock();self.queue=queue.Queue()
    def submit(self,action,options,now=None):
        with self.lock:
            if self.state['running']:raise ValueError('已有任务运行中，请等待结束')
            args=build_arguments(action,self.data,options)
            if action=='collect':self.schedule.record_collection(now)
            self.state.update(running=True,log='',message='运行中')
            self.queue.put(args)
    def record_result(self,args,error):
        if not any(command in args for command in ('daily','resume','login')):return
        with self.lock:
            was_auth=self.schedule.snapshot()['needs_auth']
            self.schedule.result(error)
            needs_auth=self.schedule.snapshot()['needs_auth']
        if needs_auth and not was_auth:notify_auth_needed()
    def tick(self,now=None):
        with self.lock:
            if not self.schedule.claim(now,busy=self.state['running']):return False
            self.state.update(running=True,log='',message='每日自动采集运行中')
            self.queue.put(build_arguments('collect',self.data,{}))
            return True


def start_or_open():
    url=existing_service(DATA)
    if not url:
        command=[sys.executable,'--background'] if getattr(sys,'frozen',False) else [sys.executable,str(Path(__file__).resolve()),'--background']
        subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        for _ in range(100):
            url=existing_service(DATA)
            if url:break
            time.sleep(.1)
    if not url:raise RuntimeError('后台服务未能启动，请查看数据目录中的后台日志')
    webbrowser.open(url)


def serve(lease=None,background=False):
    from shopee_tracker.status import read_dashboard,friendly_error
    token=secrets.token_urlsafe(32);resident=ResidentJobs(DATA)
    state=resident.state;lock=resident.lock;jobs=resident.queue
    os.environ['SHOPEE_TRACKER_KEEP_BROWSER']='1'
    class Capture:
        def __init__(self):self.error=''
        def write(self,value):
            if 'Error:'in value:self.error=value.split('Error:',1)[1].strip()
            with lock:state['log']=(state['log']+value)[-18000:]
            return len(value)
        def flush(self):pass
    def worker_loop():
        # One persistent thread owns Playwright and the Chrome connection.
        # Buttons enqueue jobs on that thread; no new browser-control session
        # is created just because the user retries or exports a result.
        while True:
            args=jobs.get();capture=Capture()
            try:
                if os.environ.get('SHOPEE_TRACKER_DEV_RELOAD')=='1':
                    import importlib
                    from shopee_tracker import browser,cli,feishu
                    for module in (browser,feishu,cli):importlib.reload(module)
                from shopee_tracker.cli import main
                with redirect_stdout(capture),redirect_stderr(capture):code=main(args)
                d=read_dashboard(DATA);count=d['summary']
                error=capture.error or (' '.join(row.get('reason','') for row in d['creators']) if code else '')
                # Collection failures are per-row and can accompany exit code 0.
                if 'daily' in args or 'resume' in args:
                    error=capture.error or ' '.join(row.get('reason','') for row in d['creators'])
                if code and not error:error='existing_chrome_connection_required' if 'login' in args else '任务未完成'
                resident.record_result(args,error)
                with lock:
                    if capture.error:state['message']=friendly_error(capture.error)
                    elif 'login'in args:state['message']='已连接你的 Chrome，Shopee 登录已核对'if code==0 else'Chrome 连接或 Shopee 登录需要处理'
                    else:state['message']=('本次处理完成' if code==0 else '本次有未完成项')+'：提取成功 %s 位，部分成功 %s 位，输出成功 %s 位'%(count['extracted'],count['partial'],count['written'])+('；截图已保存在本机'if __import__('shopee_tracker.config',fromlist=['output_mode']).output_mode(DATA/'base-config.json')=='excel'else'；飞书截图上传成功 %s 位'%count.get('proof_uploaded',0))
            except Exception as e:
                with lock:
                    state['log']+=str(e);state['message']=friendly_error(str(e))or'启动失败，请查看技术详情'
                resident.record_result(args,str(e))
            finally:
                with lock:state['running']=False
                jobs.task_done()
    threading.Thread(target=worker_loop,daemon=True).start()
    stopped=threading.Event()
    def scheduler_loop():
        while not stopped.is_set():
            try:resident.tick()
            except Exception as exc:
                with lock:state['message']='每日计划暂未启动：'+str(exc)
            stopped.wait(15)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*a):pass
        def send(self,code,body,kind='application/json',cookie=False):
            self.send_response(code);self.send_header('Content-Type',kind+'; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            if cookie:self.send_header('Set-Cookie','tracker_session='+token+'; HttpOnly; SameSite=Strict; Path=/')
            self.end_headers();self.wfile.write(body.encode())
        def do_GET(self):
            q=urlparse(self.path)
            if q.path=='/' and hmac.compare_digest(parse_qs(q.query).get('token',[''])[0],token):
                self.send_response(302);self.send_header('Location','/');self.send_header('Set-Cookie','tracker_session='+token+'; HttpOnly; SameSite=Strict; Path=/');self.end_headers();return
            if not authorized(self.headers.get('Cookie',''),token):self.send(403,'{}');return
            if q.path=='/':self.send(200,HTML,'text/html')
            elif q.path=='/state':
                with lock:
                    snapshot=dict(state);snapshot['daily']=resident.schedule.snapshot()
                    from shopee_tracker.schedule import background_agent_installed
                    snapshot['daily']['startup_installed']=bool(getattr(sys,'frozen',False) and background_agent_installed(DATA,sys.executable))
                try:
                    snapshot['dashboard']=read_dashboard(DATA)
                    if not snapshot['running']:
                        for row in snapshot['dashboard']['creators']:
                            if row['extraction']=='正在提取':row['extraction']='提取中断';row['reason']='上次任务已中断，请点击重试未完成项'
                            if row['writeback']=='正在写入':row['writeback']='写入待核验';row['reason']='上次写入结果尚未确认，请重试飞书写入'
                except Exception:
                    snapshot['dashboard']={'date':None,'creators':[],'summary':dict.fromkeys(['total','extracted','partial','failed','written','write_failed'],0)}
                from shopee_tracker.config import read_config
                snapshot['config']=public_config(read_config(DATA/'base-config.json'))
                snapshot['targets_csv']=(DATA/'targets.csv').read_text()if(DATA/'targets.csv').exists()else'country,affiliate_id,shopee_handle,url\n'
                if snapshot['config'].get('output','excel')=='excel':
                    snapshot['dashboard']['summary']['proof_failed']=0
                    for row in snapshot['dashboard']['creators']:row['cloud_proof']='截图保存在本机；Excel中提供文件路径'
                snapshot['feishu_configured']=bool(os.environ.get('FEISHU_APP_ID')and os.environ.get('FEISHU_APP_SECRET')and(DATA/'base-config.json').exists())
                self.send(200,json.dumps(snapshot,ensure_ascii=False))
            else:self.send(404,'{}')
        def do_POST(self):
            origin=self.headers.get('Origin','')
            if self.path!='/action' or not authorized(self.headers.get('Cookie',''),token) or (origin and origin!=f'http://127.0.0.1:{self.server.server_port}'):
                self.send(403,'{}');return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if length<1 or length>131072:raise ValueError('请求无效')
                value=json.loads(self.rfile.read(length));action=value.get('action')
                with lock:
                    if state['running']:raise ValueError('已有任务运行中，请等待结束')
                    if action=='folder':subprocess.Popen(['/usr/bin/open',str(DATA)]);self.send(200,'{}');return
                    if action=='settings':
                        from shopee_tracker.config import read_config,configured_targets
                        from shopee_tracker.schedule import private_json
                        mode=value.get('output')
                        if mode not in ('excel','feishu'):raise ValueError('输出请选择 Excel 或飞书')
                        raw=value.get('targets_csv','');candidate=DATA/'targets-check.csv'
                        candidate.write_text(raw)
                        from shopee_tracker.core import load_targets
                        try:
                            targets=load_targets(candidate)
                            if any(t.country!='ID'for t in targets):raise ValueError('当前仅支持印尼站')
                        finally:candidate.unlink(missing_ok=True)
                        cfg=read_config(DATA/'base-config.json')
                        extra=value.get('base_config',{})
                        if not isinstance(extra,dict):raise ValueError('飞书配置应为JSON对象')
                        if mode=='feishu':
                            from shopee_tracker.feishu import Client
                            Client(extra)
                            if not extra.get('base_token')or not extra.get('snapshot_table_id'):raise ValueError('请填写自己的Base和快照表配置')
                            cfg=public_config(extra)
                        cfg.update(output=mode,screenshot_upload_mode='app'if mode=='feishu'else'local-only')
                        private_json(DATA/'base-config.json',cfg)
                        targetfile=DATA/'targets.csv';temp=DATA/'targets.csv.tmp';temp.write_text(raw);os.chmod(temp,0o600);os.replace(temp,targetfile)
                        state['message']='达人名单和输出设置已保存';self.send(200,'{}');return
                    if action=='credentials':
                        appid=value.get('app_id','').strip();secret=value.get('secret','').strip()
                        if not appid.startswith('cli_') or not secret:raise ValueError('请填写完整的应用凭据')
                        for account,v in [('FEISHU_APP_ID',appid),('FEISHU_APP_SECRET',secret)]:
                            p=subprocess.run(['/usr/bin/security','add-generic-password','-U','-s',SERVICE,'-a',account,'-w',v],capture_output=True)
                            if p.returncode:raise ValueError('钥匙串未保存，请检查系统提示')
                            os.environ[account]=v
                        state['message']='应用凭据已保存到本机钥匙串';self.send(200,'{}');return
                    # submit takes the same lock as the daily tick.
                resident.submit(action,value);self.send(200,'{}')
            except Exception as e:self.send(400,json.dumps({'error':str(e)},ensure_ascii=False))
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    url=f'http://127.0.0.1:{server.server_port}/?token={token}'
    if lease:lease.publish(url)
    threading.Thread(target=scheduler_loop,daemon=True).start()
    if not background:
        if os.environ.get('SHOPEE_TRACKER_NO_OPEN'):print(url,flush=True)
        else:webbrowser.open(url)
    try:server.serve_forever()
    finally:stopped.set();server.server_close()

def run_app(argv=None):
    argv=sys.argv[1:] if argv is None else argv
    if argv and argv[0]=='--self-test':
        from playwright.sync_api import sync_playwright
        destination=Path(argv[1]);destination.mkdir(parents=True,exist_ok=True)
        with sync_playwright() as pw:
            browser=pw.chromium.launch(channel='chrome',headless=True)
            page=browser.new_page();page.set_content('<h1>Screenshot proof self-test</h1><p>Local synthetic page; no Shopee network.</p>')
            assert page.locator('h1').inner_text()=='Screenshot proof self-test'
            page.screenshot(path=str(destination/'browser-self-test.png'),full_page=True);browser.close()
        print('Installed Chrome + pure-code screenshot: passed',flush=True)
        raise SystemExit(0)
    if argv and argv[0]=='--cli':
        from shopee_tracker.cli import main
        raise SystemExit(main(argv[1:]))
    if argv and argv[0]=='--install-background':
        from shopee_tracker.schedule import install_background_agent
        install_background_agent(DATA,sys.executable)
        print('Daily 10:00 background service installed',flush=True)
    elif argv and argv[0]=='--background':
        with ServiceLease(DATA) as lease:
            if lease.acquired:serve(lease,background=True)
    elif os.environ.get('SHOPEE_TRACKER_NO_OPEN'):
        with ServiceLease(DATA) as lease:
            if lease.acquired:serve(lease)
    else:
        if getattr(sys,'frozen',False):
            from shopee_tracker.schedule import install_background_agent
            # Install before starting the GUI service: launchd owns its lifetime.
            install_background_agent(DATA,sys.executable)
        start_or_open()


if __name__=='__main__':
    configure()
    run_app()
