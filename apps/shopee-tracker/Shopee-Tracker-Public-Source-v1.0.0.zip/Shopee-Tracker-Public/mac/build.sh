#!/bin/bash
set -euo pipefail
TASK_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PYINSTALLER_CONFIG_DIR="${PYINSTALLER_CONFIG_DIR:-$PACKAGE_ROOT/build-cache}"
: "${BUILD_PYTHON:?Set BUILD_PYTHON to an isolated Python with PyInstaller and runtime requirements}"
"$BUILD_PYTHON" -m PyInstaller --noconfirm --clean --windowed --name 'Shopee Tracker Public' --osx-bundle-identifier com.local.shopeetracker.public --distpath "$PACKAGE_ROOT/release" --workpath "$PACKAGE_ROOT/build" --specpath "$PACKAGE_ROOT/mac" --paths "$PACKAGE_ROOT/tool" --collect-all playwright --hidden-import shopee_tracker.cli --hidden-import shopee_tracker.browser --hidden-import shopee_tracker.feishu --hidden-import shopee_tracker.attachments --hidden-import shopee_tracker.schedule --hidden-import shopee_tracker.status --hidden-import shopee_tracker.output --hidden-import shopee_tracker.config --add-data "$PACKAGE_ROOT/tool/ui.html:." --add-data "$PACKAGE_ROOT/tool/targets-id.csv:." --add-data "$PACKAGE_ROOT/tool/base-config.json:." "$PACKAGE_ROOT/mac/app_launcher.py"
APP_ROOT="$PACKAGE_ROOT/release/Shopee Tracker Public.app"
"$BUILD_PYTHON" - "$APP_ROOT/Contents/Info.plist" <<'PY'
import plistlib,sys
from pathlib import Path
p=Path(sys.argv[1]);v=plistlib.loads(p.read_bytes())
v['CFBundleShortVersionString']='1.0.0';v['CFBundleVersion']='20261023.1'
p.write_bytes(plistlib.dumps(v))
PY
# Ad-hoc integrity signing only; this is not Developer ID notarization.
codesign --force --deep --sign - "$APP_ROOT"
ditto -c -k --sequesterRsrc --keepParent "$APP_ROOT" "$PACKAGE_ROOT/Shopee-Tracker-Mac-arm64-v1.0.0.zip"
