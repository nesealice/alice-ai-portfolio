import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app_launcher import build_arguments,authorized,public_config
class LauncherTests(unittest.TestCase):
 def test_reject_arbitrary_action(self):
  with self.assertRaises(ValueError):build_arguments('shell; rm -rf /',Path('/tmp/data'),{})
 def test_collection_automatically_includes_base_writeback(self):
  args=build_arguments('collect',Path('/tmp/data'),{})
  self.assertIn('daily',args)
  self.assertEqual(args[-2:],['--config','/tmp/data/base-config.json'])
 def test_writeback_uses_private_config(self):
  args=build_arguments('writeback',Path('/tmp/data'),{})
  self.assertEqual(args[-1],'/tmp/data/base-config.json')
 def test_no_cookie_or_wrong_token_cannot_control(self):
  self.assertFalse(authorized('', 'secret'))
  self.assertFalse(authorized('tracker_session=wrong','secret'))
  self.assertTrue(authorized('tracker_session=secret','secret'))
 def test_distributed_config_excludes_credentials(self):
  c=public_config({'base_token':'a','FEISHU_APP_SECRET':'secret','app_secret':'secret','api_origin':'https://open.feishu.cn'})
  self.assertNotIn('app_secret',c);self.assertNotIn('FEISHU_APP_SECRET',c);self.assertEqual(c['base_token'],'a')
 def test_primary_ui_shows_status_instead_of_requiring_log_reading(self):
  from app_launcher import HTML
  self.assertIn('开始采集并保存',HTML)
  self.assertIn('提取状态',HTML)
  self.assertIn('目标写入',HTML)
  self.assertIn('<details>',HTML)

class ResidentLauncherTests(unittest.TestCase):
 def test_singleton_lock_and_discovery_are_private(self):
  import tempfile,os,json
  from app_launcher import ServiceLease
  with tempfile.TemporaryDirectory() as tmp:
   data=Path(tmp)/'data'
   with ServiceLease(data) as first:
    self.assertTrue(first.acquired)
    first.publish('http://127.0.0.1:1234/?token=private')
    self.assertEqual(os.stat(data/'service.json').st_mode&0o777,0o600)
    self.assertEqual(os.stat(data).st_mode&0o777,0o700)
    with ServiceLease(data) as second:self.assertFalse(second.acquired)
   self.assertFalse((data/'service.json').exists())
   with ServiceLease(data) as restarted:self.assertTrue(restarted.acquired)
 def test_discovery_verifies_token_and_server_health(self):
  import tempfile,json
  from unittest.mock import patch,MagicMock
  from app_launcher import existing_service
  with tempfile.TemporaryDirectory() as tmp:
   data=Path(tmp);(data/'service.json').write_text(json.dumps({'url':'http://127.0.0.1:1234/?token=private'}))
   with patch('app_launcher.urlopen') as request:
    request.return_value.__enter__.return_value.status=200
    self.assertEqual(existing_service(data),'http://127.0.0.1:1234/?token=private')
    self.assertEqual(request.call_args.args[0].get_header('Cookie'),'tracker_session=private')
   with patch('app_launcher.urlopen',side_effect=OSError):self.assertIsNone(existing_service(data))
 def test_discovery_rejects_remote_urls(self):
  import tempfile,json
  from app_launcher import existing_service
  with tempfile.TemporaryDirectory() as tmp:
   data=Path(tmp);(data/'service.json').write_text(json.dumps({'url':'https://example.com/?token=private'}))
   self.assertIsNone(existing_service(data))
 def test_ui_explains_daily_status(self):
  from app_launcher import HTML
  self.assertIn('dailyStatus',HTML)
  self.assertIn('next_run',HTML)
  self.assertIn('needs_auth',HTML)
 def test_scheduler_and_buttons_share_single_queue_and_busy_gate(self):
  import tempfile
  from datetime import datetime
  from app_launcher import ResidentJobs
  with tempfile.TemporaryDirectory() as tmp:
   jobs=ResidentJobs(Path(tmp));now=datetime(2026,10,23,10,0)
   self.assertTrue(jobs.tick(now));self.assertFalse(jobs.tick(now))
   with self.assertRaises(ValueError):jobs.submit('collect',{})
   args=jobs.queue.get_nowait();self.assertIn('daily',args)
   self.assertEqual(jobs.queue.qsize(),0)
   with jobs.lock:jobs.state['running']=False
   self.assertFalse(jobs.tick(now))
 def test_installer_does_not_restart_matching_loaded_service(self):
  import tempfile,subprocess
  from unittest.mock import Mock
  from shopee_tracker.schedule import write_background_agent,install_background_agent
  with tempfile.TemporaryDirectory() as tmp:
   data=Path(tmp)/'data';agents=Path(tmp)/'agents';exe=Path(tmp)/'app'
   write_background_agent(data,exe,agents)
   runner=Mock(return_value=subprocess.CompletedProcess([],0))
   install_background_agent(data,exe,agents,runner)
   self.assertEqual(runner.call_count,1)
   self.assertEqual(runner.call_args.args[0][1],'print')
 def test_background_service_keeps_one_worker_for_multiple_http_jobs(self):
  import tempfile,subprocess,json,time,os
  from urllib.request import Request,urlopen
  from urllib.parse import urlparse,parse_qs
  from app_launcher import existing_service
  with tempfile.TemporaryDirectory() as tmp:
   data=Path(tmp)
   script='''import sys,json,threading,time
from pathlib import Path
from datetime import datetime
import app_launcher as app
from shopee_tracker.schedule import DailySchedule
from shopee_tracker import cli
app.DATA=Path(sys.argv[1]);DailySchedule(app.DATA).record_collection()
def main(args):
 with (app.DATA/'calls.jsonl').open('a') as f:f.write(json.dumps({'args':args,'thread':threading.get_ident()})+'\\n')
 time.sleep(.1)
 return 0
cli.main=main
with app.ServiceLease(app.DATA) as lease:
 app.serve(lease,background=True)
'''
   env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(Path(__file__).resolve().parents[1]),str(Path(__file__).resolve().parents[2]/'tool')]))
   child=subprocess.Popen([sys.executable,'-c',script,str(data)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:
    url=None
    for _ in range(100):
     url=existing_service(data)
     if url:break
     if child.poll() is not None:self.fail(child.stderr.read().decode())
     time.sleep(.03)
    self.assertIsNotNone(url)
    parsed=urlparse(url);base=f'http://127.0.0.1:{parsed.port}';cookie='tracker_session='+parse_qs(parsed.query)['token'][0]
    for action in ('collect','export'):
     req=Request(base+'/action',data=json.dumps({'action':action}).encode(),headers={'Cookie':cookie,'Content-Type':'application/json','Origin':base})
     with urlopen(req,timeout=2) as response:self.assertEqual(response.status,200)
     for _ in range(100):
      with urlopen(Request(base+'/state',headers={'Cookie':cookie}),timeout=2) as response:state=json.load(response)
      if not state['running']:break
      time.sleep(.02)
     self.assertFalse(state['running']);self.assertTrue(state['daily']['enabled'])
    calls=[json.loads(line) for line in (data/'calls.jsonl').read_text().splitlines()]
    self.assertEqual(len(calls),2);self.assertEqual(calls[0]['thread'],calls[1]['thread'])
    self.assertIn('daily',calls[0]['args']);self.assertIn('export',calls[1]['args'])
   finally:
    child.terminate();out,err=child.communicate(timeout=5)
   self.assertEqual(out,b'');self.assertEqual(err,b'')
 def test_only_auth_failure_notifies_and_export_preserves_auth_state(self):
  import tempfile
  from unittest.mock import patch
  from app_launcher import ResidentJobs
  with tempfile.TemporaryDirectory() as tmp,patch('app_launcher.notify_auth_needed') as notify:
   jobs=ResidentJobs(Path(tmp));daily=build_arguments('collect',Path(tmp),{})
   jobs.record_result(daily,'login_required')
   self.assertTrue(jobs.schedule.snapshot()['needs_auth']);self.assertEqual(notify.call_count,1)
   jobs.record_result(daily,'login_required');self.assertEqual(notify.call_count,1)
   jobs.record_result(build_arguments('export',Path(tmp),{}),'')
   self.assertTrue(jobs.schedule.snapshot()['needs_auth'])
   jobs.record_result(daily,'loading_timeout')
   self.assertFalse(jobs.schedule.snapshot()['needs_auth']);self.assertEqual(notify.call_count,1)

 def test_normal_packaged_launch_installs_before_opening_service(self):
  from unittest.mock import patch
  import app_launcher as app
  events=[]
  with patch.object(app.sys,'frozen',True,create=True),patch.dict(app.os.environ,{},clear=True),patch('shopee_tracker.schedule.install_background_agent',side_effect=lambda *args:events.append('install')),patch.object(app,'start_or_open',side_effect=lambda:events.append('open')):
   app.run_app([])
  self.assertEqual(events,['install','open'])
 def test_background_and_cli_entrypoints_never_install(self):
  from unittest.mock import patch,MagicMock
  import app_launcher as app
  with patch.object(app.sys,'frozen',True,create=True),patch('shopee_tracker.schedule.install_background_agent') as install,patch.object(app,'ServiceLease') as lease,patch.object(app,'serve') as serve,patch('shopee_tracker.cli.main',return_value=0):
   lease.return_value.__enter__.return_value.acquired=True
   app.run_app(['--background'])
   serve.assert_called_once()
   with self.assertRaises(SystemExit):app.run_app(['--cli','status'])
   install.assert_not_called()
 def test_source_gui_launch_does_not_install_login_agent(self):
  from unittest.mock import patch
  import app_launcher as app
  with patch.object(app.sys,'frozen',False,create=True),patch.dict(app.os.environ,{},clear=True),patch('shopee_tracker.schedule.install_background_agent') as install,patch.object(app,'start_or_open') as opening:
   app.run_app([])
   install.assert_not_called();opening.assert_called_once()

 def test_self_test_does_not_install_login_agent(self):
  import tempfile,types
  from unittest.mock import patch,MagicMock
  import app_launcher as app
  api=types.ModuleType('playwright.sync_api');api.sync_playwright=MagicMock()
  browser=api.sync_playwright.return_value.__enter__.return_value.chromium.launch.return_value
  browser.new_page.return_value.locator.return_value.inner_text.return_value='Screenshot proof self-test'
  with tempfile.TemporaryDirectory() as tmp,patch.object(app.sys,'frozen',True,create=True),patch.dict(sys.modules,{'playwright.sync_api':api}),patch('shopee_tracker.schedule.install_background_agent') as install,patch('builtins.print'):
   with self.assertRaises(SystemExit):app.run_app(['--self-test',tmp])
   install.assert_not_called()

if __name__=='__main__':unittest.main()
