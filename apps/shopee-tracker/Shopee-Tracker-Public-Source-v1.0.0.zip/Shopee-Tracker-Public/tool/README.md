See ../README.md for installation, configuration and metric semantics.
