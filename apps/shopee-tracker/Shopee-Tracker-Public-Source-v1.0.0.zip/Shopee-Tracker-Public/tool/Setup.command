#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
TRACKER_DATA="${SHOPEE_TRACKER_DATA_DIR:-$HOME/Library/Application Support/ShopeeTrackerPublic}"
TRACKER_PYTHON="${SHOPEE_TRACKER_PYTHON:-python3}"
if ! "$TRACKER_PYTHON" -c 'import sys; assert sys.version_info >= (3,10)' 2>/dev/null; then
  echo 'Source launcher needs Python 3.10 or newer. Use the packaged Mac app when available, or install Python from python.org.'
  exit 1
fi
mkdir -p "$TRACKER_DATA"
chmod 700 "$TRACKER_DATA"
if [ ! -x "$TRACKER_DATA/venv/bin/python" ]; then
  "$TRACKER_PYTHON" -m venv "$TRACKER_DATA/venv"
fi
"$TRACKER_DATA/venv/bin/python" -m pip install --requirement requirements.txt
if [ ! -d "/Applications/Google Chrome.app" ]; then
  echo "请先从 Google 官方安装正式版 Chrome，再运行工具。"
  exit 1
fi
if [ ! -f "$TRACKER_DATA/base-config.json" ] && [ -f base-config.json ]; then
  cp base-config.json "$TRACKER_DATA/base-config.json"
fi
if [ ! -f "$TRACKER_DATA/targets.csv" ]; then cp targets-id.csv "$TRACKER_DATA/targets.csv"; fi
echo 'Ready. Double-click Shopee Tracker.command to open the local command menu.'
