#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
TRACKER_DATA="${SHOPEE_TRACKER_DATA_DIR:-$HOME/Library/Application Support/ShopeeTrackerPublic}"
TRACKER_PY="$TRACKER_DATA/venv/bin/python"
if [ ! -x "$TRACKER_PY" ]; then
  echo 'Run Setup.command once to prepare this Mac.'
  read -r -p 'Press Enter to close.'
  exit 1
fi
if [ "$#" -gt 0 ]; then
  exec "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" "$@"
fi
while true; do
  echo
  echo 'Shopee Tracker — Indonesia / configurable creators / rolling Last 7 Days'
  echo '1 Login  2 Collect today  3 Resume  4 Status  5 Export  6 Write to Base  7 Preview Base records  0 Quit'
  read -r -p 'Choose: ' TRACKER_CHOICE
  case "$TRACKER_CHOICE" in
    1) "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" login || true ;;
    2) "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" collect || true ;;
    3) "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" resume || true ;;
    4) "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" status || true ;;
    5) "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" export --output "$TRACKER_DATA/exports/manual-$(date +%Y%m%d-%H%M%S)" || true ;;
    6) "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" writeback || true ;;
    7) "$TRACKER_PY" -m shopee_tracker --data-dir "$TRACKER_DATA" writeback --preview || true ;;
    0) exit 0 ;;
    *) echo 'Choose 0 to 7.' ;;
  esac
done
