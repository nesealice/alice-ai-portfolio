"""Deterministic, local Shopee rolling-window snapshots. No AI services."""
