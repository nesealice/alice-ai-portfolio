"""App HTTP screenshot proofs with durable tokens and filename reconciliation.
The explicitly enabled legacy CLI bridge never inspects CLI credentials.
"""
import json,os
from pathlib import Path
import shutil
import subprocess


def _upload_cli_proofs(config,store,key,record_id,paths,client):
    missing_count=sum(1 for p in paths if not p)
    paths=[Path(p).resolve() for p in paths if p]
    if config.get('screenshot_upload_mode')!='lark-cli-user':
        return {'state':'local_only','notes':'Current channel screenshots retained locally; optional official CLI upload not enabled'}
    if not paths or any(not p.is_file() for p in paths):
        return {'state':'missing_local_proof','notes':'One or more current screenshots are unavailable; nothing uploaded'}
    cli=shutil.which('lark-cli')
    if not cli:
        return {'state':'cli_unavailable','notes':'Install and independently authorize official lark-cli on this Mac; local screenshots preserved'}
    store.db.execute('CREATE TABLE IF NOT EXISTS attachment_uploads(snapshot_key TEXT PRIMARY KEY,state TEXT,details TEXT)')
    store.db.commit()
    def checkpoint(state,notes):
        if missing_count:
            notes+=' | Missing current screenshot channels: '+str(missing_count)
            if state=='uploaded_verified':
                state='partial_uploaded_verified'
        result={'state':state,'notes':notes,'paths':[str(p) for p in paths]}
        with store.db:
            store.db.execute('INSERT OR REPLACE INTO attachment_uploads VALUES(?,?,?)',(key,state,json.dumps(result)))
        return result
    seen_names=set()
    def reconciled():
        row=next((r for r in client.records() if r['record_id']==record_id),None)
        if not row:
            return False
        files=row['fields'].get('Screenshot') or []
        if not isinstance(files,list):
            return False
        names={x.get('name') or x.get('file_name') for x in files if isinstance(x,dict)}
        seen_names.clear();seen_names.update(names)
        return all(p.name in names for p in paths)
    try:
        if reconciled():
            return checkpoint('uploaded_verified','Current screenshot filenames found in Base attachment cell')
    except Exception:
        # Do not erase an earlier uncertain mutation checkpoint when a later
        # read fails; otherwise the next attempt could duplicate that upload.
        return {'state':'readback_failed','notes':'Could not inspect existing Base attachments. Nothing uploaded; local screenshots preserved'}
    previous=store.db.execute('SELECT state,details FROM attachment_uploads WHERE snapshot_key=?',(key,)).fetchone()
    if previous and previous[0] in ('upload_started','upload_unconfirmed'):
        return checkpoint('upload_unconfirmed','Earlier upload outcome is uncertain. No duplicate upload attempted; reconcile attachment filenames manually')
    args=[cli,'base','+record-upload-attachment','--base-token',config['base_token'],
          '--table-id',config.get('snapshot_table_id',config.get('snapshots_table_id')),
          '--record-id',record_id,'--field-id','Screenshot','--as','user','--format','json']
    working=Path(os.path.commonpath([str(p.parent)for p in paths]))
    for path in paths:
        if path.name in seen_names:continue
        args.extend(['--file',str(path.relative_to(working))])
    checkpoint('upload_started','Official CLI upload started; request outcome must be reconciled before retry')
    error=None
    try:
        result=subprocess.run(args,cwd=working,capture_output=True,text=True,timeout=180,check=False)
        if result.returncode:
            error='CLI returned an error; verify local user authorization and Base permissions'
    except (subprocess.TimeoutExpired,OSError):
        error='CLI response unavailable; upload may have committed'
    try:
        if reconciled():
            return checkpoint('uploaded_verified','Current screenshot filenames verified in Base after CLI upload')
    except Exception:
        pass
    return checkpoint('upload_unconfirmed',(error or 'CLI completed but attachment readback did not verify all current filenames')+'. Local proof remains available; no automatic duplicate upload.')


def _update_cli_status(config,record_id,result):
    """Update only proof status via the explicitly enabled local user CLI."""
    cli=shutil.which('lark-cli')
    if not cli or config.get('screenshot_upload_mode')!='lark-cli-user':
        return False
    fields={'Screenshot Status':result['state']+' | '+result['notes']}
    try:
        outcome=subprocess.run([cli,'base','+record-upsert','--base-token',config['base_token'],
            '--table-id',config.get('snapshot_table_id',config.get('snapshots_table_id')),
            '--record-id',record_id,'--json',json.dumps(fields,ensure_ascii=False),
            '--as','user','--format','json'],capture_output=True,text=True,timeout=40,check=False)
        return outcome.returncode==0
    except (subprocess.TimeoutExpired,OSError):
        return False


from hashlib import sha256
from urllib.parse import quote
from .media import upload_media, MediaRejected, MAX_IMAGE_BYTES
from .feishu import FeishuError


def upload_proofs(config,store,key,record_id,paths,client):
    """Upload current proofs through app HTTP; never retry an ambiguous mutation."""
    if config.get('screenshot_upload_mode')=='lark-cli-user':
        return _upload_cli_proofs(config,store,key,record_id,paths,client)
    if config.get('screenshot_upload_mode','app') not in ('app','app-http'):
        return {'state':'local_only','notes':'Screenshot upload disabled; current proof retained locally'}
    missing=sum(not p for p in paths)
    paths=[Path(p).resolve() for p in paths if p]
    if not paths or any(not p.is_file() for p in paths):
        return {'state':'missing_local_proof','notes':'Current screenshot files unavailable; nothing uploaded'}
    store.db.execute('CREATE TABLE IF NOT EXISTS attachment_files(proof_key TEXT PRIMARY KEY,state TEXT,details TEXT)')
    store.db.execute('CREATE TABLE IF NOT EXISTS attachment_uploads(snapshot_key TEXT PRIMARY KEY,state TEXT,details TEXT)')
    store.db.commit()
    def checkpoint(state,notes):
        if missing:
            notes+=' | Missing current screenshot channels: '+str(missing)
            if state=='uploaded_verified':state='partial_uploaded_verified'
        result={'state':state,'notes':notes,'paths':[str(p) for p in paths]}
        with store.db:store.db.execute('INSERT OR REPLACE INTO attachment_uploads VALUES(?,?,?)',(key,state,json.dumps(result)))
        return result
    def names():
        row=next((r for r in client.records() if r['record_id']==record_id),None)
        if row is None:raise ValueError('Snapshot record not found')
        files=row['fields'].get('Screenshot') or []
        if not isinstance(files,list):raise ValueError('Screenshot field is not an attachment list')
        return {f.get('name') or f.get('file_name') for f in files if isinstance(f,dict)}
    try:seen=names()
    except Exception:return checkpoint('readback_failed','Could not inspect current Base attachments; nothing uploaded')
    pending=[]
    for path in paths:
        if path.name in seen:continue
        # Record, Base, filename and content all scope the durable upload token.
        try:
            with path.open('rb') as proof:content=proof.read(MAX_IMAGE_BYTES+1)
            if len(content)>MAX_IMAGE_BYTES:return checkpoint('invalid_local_proof','Screenshot exceeds media upload size limit')
            digest=sha256(content).hexdigest()
            del content
        except OSError:return checkpoint('missing_local_proof','Current screenshot could not be read')
        identity=json.dumps([config['base_token'],config.get('snapshot_table_id',config.get('snapshots_table_id')),record_id,key,path.name,digest])
        proof_key=sha256(identity.encode()).hexdigest()
        previous=store.db.execute('SELECT state,details FROM attachment_files WHERE proof_key=?',(proof_key,)).fetchone()
        def save(state,details):
            with store.db:store.db.execute('INSERT OR REPLACE INTO attachment_files VALUES(?,?,?)',(proof_key,state,json.dumps(details)))
        details=json.loads(previous[1]) if previous else {'name':path.name,'sha256':digest}
        if previous and previous[0] in ('upload_started','upload_unconfirmed','append_started','append_unconfirmed'):
            return checkpoint('append_unconfirmed' if previous[0].startswith('append') else 'upload_unconfirmed','Earlier screenshot mutation remains unconfirmed after filename readback; no duplicate attempted')
        if not details.get('file_token'):
            save('upload_started',details)
            try:details.update(upload_media(client,config['base_token'],path))
            except MediaRejected as exc:
                save('upload_rejected',details)
                return checkpoint('upload_rejected','Media upload rejected: '+str(exc)[:400]+'; local proof retained')
            except Exception as exc:
                save('upload_unconfirmed',details)
                return checkpoint('upload_unconfirmed','Media upload unavailable: '+str(exc)[:400]+'; local proof retained')
            save('uploaded',details)
        pending.append((proof_key,details))
    if pending:
        attachments=[{k:v for k,v in details.items() if k in ('file_token','image_width','image_height')} for _,details in pending]
        with store.db:
            for proof_key,details in pending:store.db.execute('UPDATE attachment_files SET state=? WHERE proof_key=?',('append_started',proof_key))
        base=quote(config['base_token'],safe='');table=quote(config.get('snapshot_table_id',config.get('snapshots_table_id')),safe='')
        error=None;rejected=False
        try:client.request('POST','/open-apis/base/v3/bases/'+base+'/tables/'+table+'/append_attachments',{'attachments':{record_id:{'Screenshot':attachments}}})
        except Exception as exc:
            error=str(exc)[:400]
            rejected=isinstance(exc,FeishuError) and (error.startswith('Feishu API code ') or any(error.startswith('Feishu HTTP error '+str(code)+' ') for code in range(400,500) if code!=408))
        try:seen=names()
        except Exception:seen=set()
        verified=all(path.name in seen for path in paths)
        with store.db:
            for proof_key,details in pending:
                store.db.execute('UPDATE attachment_files SET state=? WHERE proof_key=?',('verified' if details['name'] in seen else ('append_rejected' if rejected else 'append_unconfirmed'),proof_key))
        if not verified:return checkpoint('append_rejected' if rejected else 'append_unconfirmed','Attachment append not verified; uploaded media tokens retained'+(': '+error if error else ''))
    return checkpoint('uploaded_verified','Current screenshot filenames verified in Base attachment cell')


def update_cloud_status(config,record_id,result,client=None):
    if config.get('screenshot_upload_mode')=='lark-cli-user':return _update_cli_status(config,record_id,result)
    try:
        if client is None:
            from .feishu import Client
            client=Client(config)
        client.update(record_id,{'Screenshot Status':result['state']+' | '+result['notes']})
        return True
    except Exception:return False
