"""Read only visible DOM. Unrecognized selection/layout fails closed.

The label set comes from observed ID English UI; TH must pass the same checks or
receive a locally calibrated selectors.json. No hidden Shopee API is called.
"""
import json
import os
import threading
import re
import time
from datetime import datetime, timezone
if os.environ.get('SHOPEE_TRACKER_DEV_RELOAD')=='1':
    import importlib
    from . import core as _core
    importlib.reload(_core)
from .core import (DOMAINS, LABELS, UnsupportedDOM, verify_identity, extract_metrics, validate_url)


def selected_evidence(attrs):
    if any(attrs.get(k) == 'true' for k in ('aria-selected','aria-pressed','aria-checked')):
        return True
    classes=re.split(r'\s+',attrs.get('class',''))
    return bool(set(classes)&{'active','selected','current','checked'})or any(re.search(r'(?:^|---)selected-platform--',c)for c in classes)


def detect_blocker(url, text):
    if re.search(r"(?i)verification can[’']t be completed|verification cannot be completed|please try again later",text):
        return 'verification_unavailable'
    if re.search(r'(?i)/(?:account/)?(?:login|signin)', url):
        return 'login_required'
    if re.search(r'(?i)verify you are human|security verification|complete the captcha|slide to verify|verifikasi keamanan', text):
        return 'verification_required'
    if re.search(r'(?i)you do not have permission|access denied|no permission|tidak memiliki akses', text):
        return 'no_permission'
    return None


def scope_text(text, channel):
    if text.count('\nViews\n') > 1 or ('Shopee Live' in text and 'Shopee Video' in text):
        raise UnsupportedDOM('Channel container mixes multiple sections')
    if channel != 'sales' and 'Sales Metrics' in text:
        raise UnsupportedDOM('Channel container includes overall Sales Metrics')
    return text


# Traverse metric card ancestors, bounded by other metric labels. Visible text is
# read as rendered; this deliberately excludes hidden page data / script state.
CARD_JS = r'''(element, labels) => {
  let node = element;
  for (let depth=0; node && depth<7; depth++,node=node.parentElement) {
    let lines=(node.innerText||'').split(/\n/).map(s=>s.trim()).filter(Boolean);
    let hits=lines.filter(s=>labels.includes(s));
    if(hits.length>1) return null;
    if(hits.length===1 && lines.length>1 && lines[0]===element.innerText.trim()) {
      let next=lines[1];
      if(!/^vs\s/i.test(next) && /[\d—–-]|No Data|Tidak Ada Data/i.test(next))
        return lines.join('\n');
    }
  }
  return null;
}'''


class VisibleAdapter:
    def __init__(self, page, selectors=None):
        self.page = page
        self.selectors = selectors or {}

    def visible_text(self):
        text = self.page.locator('body').inner_text(timeout=15000)
        blocker = detect_blocker(self.page.url, text)
        if blocker:
            raise UnsupportedDOM(blocker)
        return text

    def one_text(self, text):
        matches = self.page.get_by_text(text, exact=True)
        visible = [matches.nth(i) for i in range(matches.count()) if matches.nth(i).is_visible()]
        if len(visible) != 1:
            raise UnsupportedDOM('Expected one visible control: ' + text)
        return visible[0]

    def wait_ready(self,timeout=60):
        # Loading masks must disappear, then independently read stable DOM twice.
        self.page.locator('body').wait_for(state='visible')
        loading = self.page.locator('[aria-busy="true"], [role="progressbar"], .shopee-spin-spinning')
        deadline = time.monotonic() + timeout
        previous = None
        stable = 0
        while time.monotonic() < deadline:
            text=self.visible_text()
            metric_content=bool(re.search(r'(?im)^(?:Clicks|Items Sold|Orders|GMV(?:\(Rp\))?|ROI)\s*\n\s*(?:Rp\s*)?(?:[<>]?\s*[0-9—–-]|No Data|Tidak Ada Data)',text))
            ready=('Sales Metrics' in text and metric_content and bool(re.search(r'(?m)^Last (?:7|15|30|90) Days$',text)))
            if not ready or any(loading.nth(i).is_visible() for i in range(loading.count())):
                stable = 0
            else:
                text = self.visible_text()
                stable = stable + 1 if text == previous else 0
                if stable >= 2:
                    return text
                previous = text
            self.page.wait_for_timeout(600)
        raise UnsupportedDOM('loading_timeout: creator metric panels did not finish loading within %s seconds'%timeout)

    def verify_period(self):
        text = self.visible_text()
        configured = self.selectors.get('period_selected')
        if configured:
            loc = self.page.locator(configured)
            if loc.count() != 1 or not loc.is_visible() or loc.inner_text().strip() != 'Last 7 Days':
                raise UnsupportedDOM('Configured period evidence does not show Last 7 Days')
            return {'selected':'Last 7 Days','method':'configured_visible_selector'}
        # Shopee keeps hidden/animating menu options in the DOM. Inspect the
        # dedicated closed select control instead of all matching option text.
        current=self.page.locator('.eds-react-select__inner')
        candidates=[current.nth(i)for i in range(current.count())if current.nth(i).is_visible()and re.fullmatch(r'Last (7|15|30|90) Days',current.nth(i).inner_text().strip())]
        if candidates:
            if len(candidates)!=1 or candidates[0].inner_text().strip()!='Last 7 Days':raise UnsupportedDOM('Seven-day period not selected in actual control')
            return {'selected':'Last 7 Days','method':'actual_select_current_value'}
        periods=[line.strip()for line in text.splitlines()if re.fullmatch(r'Last (7|15|30|90) Days',line.strip())]
        if periods!=['Last 7 Days']:raise UnsupportedDOM('Seven-day period not exclusively displayed; menu may still be open')
        self.one_text('Last 7 Days')
        return {'selected':'Last 7 Days','method':'closed_dropdown_current_value'}

    def set_period(self):
        text=self.visible_text()
        choices=re.findall(r'(?m)^Last (?:7|15|30|90) Days$',text)
        if len(choices)!=1:raise UnsupportedDOM('Cannot identify single closed period dropdown')
        if choices[0]!='Last 7 Days':
            # The real select menu animates and replaces option nodes. Click the
            # visible DOM control directly, then prove the resulting state.
            self.one_text(choices[0]).evaluate('(el)=>el.click()')
            options=self.page.locator('.eds-react-select-option').filter(has_text=re.compile(r'^Last 7 Days$'))
            if options.count():
                options.wait_for(state='visible',timeout=10000)
                options.evaluate('(el)=>el.click()')
            else:
                self.page.get_by_text('Last 7 Days',exact=True).wait_for(state='visible',timeout=10000)
                self.one_text('Last 7 Days').evaluate('(el)=>el.click()')
            # Shopee's hover menu can stay open after selection. Move focus to
            # a non-interactive heading before requiring exclusive period text.
            self.one_text('Sales Metrics').click(force=True)
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            text=self.visible_text()
            selected=re.findall(r'(?m)^Last (?:7|15|30|90) Days$',text)
            comparisons=re.findall(r'vs Previous (\d+) Days',text)
            try:
                self.verify_period()
                selected_seven=True
            except UnsupportedDOM:selected_seven=False
            if selected_seven and all(x=='7'for x in comparisons):break
            self.page.wait_for_timeout(400)
        else:
            current=self.page.locator('.eds-react-select__inner')
            controls=[current.nth(i).inner_text()for i in range(current.count())if current.nth(i).is_visible()]
            raise UnsupportedDOM('Seven-day selected control or comparison panels have not refreshed; displayed=%r; comparisons=%r; controls=%r'%(selected,comparisons,controls))
        self.wait_ready()
        self.verify_period()
        # Reload would reset Shopee to Last 30 Days, so this state is read as-is.

    def select_channel(self, channel):
        label = {'live':'Shopee Live','video':'Shopee Video'}[channel]
        matches=self.page.get_by_text(label,exact=True)
        if not any(matches.nth(i).is_visible()for i in range(matches.count())):
            other=self.page.get_by_text('Shopee Video'if channel=='live'else'Shopee Live',exact=True)
            if any(other.nth(i).is_visible()for i in range(other.count()))and 'Shopee Internal Channel'in self.visible_text():
                raise UnsupportedDOM('channel_not_offered: '+label+' is not provided on this creator page')
        control = self.one_text(label)
        # Metric charts can keep the layout moving. Activate the uniquely
        # visible channel node, then independently verify selected class/ARIA.
        control.evaluate('(el)=>el.click()')
        self.wait_ready()
        configured = self.selectors.get(channel + '_selected')
        if configured:
            selected = self.page.locator(configured)
            if selected.count() != 1 or not selected.is_visible() or selected.inner_text().strip() != label:
                raise UnsupportedDOM('Configured channel selection not confirmed: ' + label)
            return {'selected':label,'method':'configured_visible_selector'}
        # The observed UI uses generic elements. Inspect actual node + ancestors;
        # a common parent with both labels cannot prove either channel selected.
        attrs = control.evaluate('''el => {
          const out=[];
          for(let i=0;el&&i<4;i++,el=el.parentElement){
            if(el.innerText.includes('Shopee Live')&&el.innerText.includes('Shopee Video')) break;
            out.push({text:el.innerText,class:el.className||'',
              'aria-selected':el.getAttribute('aria-selected'),
              'aria-pressed':el.getAttribute('aria-pressed'),
              'aria-checked':el.getAttribute('aria-checked')});
          } return out;
        }''')
        if not any(selected_evidence(a) for a in attrs):
            raise UnsupportedDOM('Selected channel class/ARIA unsupported; calibrate selectors.json: ' + label)
        return {'selected':label,'method':'visible_class_or_aria','attributes':attrs}

    def container(self,channel):
        configured=self.selectors.get('sales_container' if channel=='sales' else 'channel_container')
        heading='Sales Metrics' if channel=='sales' else 'Shopee Internal Channel'
        forbidden='Shopee Internal Channel' if channel=='sales' else 'Sales Metrics'
        if configured:
            container=self.page.locator(configured)
            if container.count()!=1 or not container.is_visible():
                raise UnsupportedDOM('Configured metric section is not uniquely visible')
        else:
            anchor=self.one_text(heading)
            depth=anchor.evaluate(r"""(el,args) => {
              for(let depth=0;el&&depth<9;depth++,el=el.parentElement){
                let lines=(el.innerText||'').split(/\n/).map(x=>x.trim()).filter(Boolean);
                if(lines.includes(args.forbidden)) return -1;
                if(lines.includes(args.heading) &&
                   (lines.some(x=>args.labels.includes(x)) || lines.some(x=>/^(No Data|Tidak Ada Data)$/i.test(x)))) return depth;
              } return -1;
            }""",{'heading':heading,'forbidden':forbidden,'labels':list(LABELS[channel])})
            if depth<0:
                raise UnsupportedDOM('Cannot establish isolated metric section: '+heading)
            container=anchor
            for _ in range(depth):
                container=container.locator('xpath=..')
        lines=[x.strip() for x in container.inner_text().splitlines()]
        if heading not in lines or forbidden in lines:
            raise UnsupportedDOM('Metric section is mixed with another channel or missing its heading')
        return container

    def panel(self,section,channel):
        if channel=='sales':
            return section
        configured=self.selectors.get(channel+'_container')
        exclusive={'live':['Livestream Session'],
                   'video':['Video Post','Video','Videos','Video Published','Videos Published','Published Videos']}
        opposite=exclusive['video' if channel=='live' else 'live']
        forbidden=opposite+['Sales Metrics','Shopee Internal Channel','Shopee Live','Shopee Video']
        if configured:
            panel=section.locator(configured)
            if panel.count()!=1 or not panel.is_visible():
                raise UnsupportedDOM('Configured active panel is not uniquely visible')
        else:
            anchors=[]
            for label in exclusive[channel]:
                matches=section.get_by_text(label,exact=True)
                anchors.extend(matches.nth(i) for i in range(matches.count()) if matches.nth(i).is_visible())
            if len(anchors)!=1:
                raise UnsupportedDOM('Cannot prove channel-specific metric panel; configure '+channel+'_container')
            anchor=anchors[0]
            depth=anchor.evaluate(r"""(el,forbidden) => {
              let best=-1;
              for(let depth=0;el&&depth<9;depth++,el=el.parentElement){
                let lines=(el.innerText||'').split(/\n/).map(x=>x.trim()).filter(Boolean);
                if(lines.some(x=>forbidden.includes(x)))break;
                if(lines.length>1)best=depth;
              }return best;
            }""",forbidden)
            if depth<0:
                raise UnsupportedDOM('No isolated active metric panel')
            panel=anchor
            for _ in range(depth):
                panel=panel.locator('xpath=..')
        if any(x.strip() in forbidden for x in panel.inner_text().splitlines()):
            raise UnsupportedDOM('Active panel contains another channel or its controls')
        return panel

    def verify_target(self,target,text):
        if validate_url(self.page.url)!=(target.country,target.affiliate_id):
            raise UnsupportedDOM('Identity mismatch: current URL differs from target')
        # A username can change while the official affiliate_id remains stable.
        # Use only the observed official profile header, not arbitrary page text.
        header=self.page.locator('[class*="UserInfo---name--"]')
        visible=[header.nth(i)for i in range(header.count())if header.nth(i).is_visible()]
        if len(visible)==1:
            actual=visible[0].inner_text().strip().lstrip('@')
            if actual and actual in [x.strip().lstrip('@')for x in text.splitlines()]:
                return {'method':'official_affiliate_id_and_profile_header','affiliate_id':target.affiliate_id,'observed_handle':actual,'source_handle':target.shopee_handle,'handle_changed':actual!=target.shopee_handle}
        verify_identity(target,self.page.url,text)
        return {'method':'exact_source_handle_and_affiliate_id','observed_handle':target.shopee_handle,'handle_changed':False}

    def read(self, target, channel, folder):
        text = self.wait_ready()
        identity=self.verify_target(target,text)
        period = self.verify_period()
        updated = re.search(r'Last update time\s*:?\s*([^\n]+)',text)
        if not updated:
            raise UnsupportedDOM('Last update time is not displayed; refresh evidence unavailable')
        selected = {'selected':'Sales Metrics','method':'overall_section'} if channel == 'sales' else self.select_channel(channel)
        self.verify_period()
        self.verify_target(target,self.visible_text())
        section=self.panel(self.container(channel),channel)
        cards = []
        all_labels = list(set(sum((list(x) for x in LABELS.values()),[])))
        for label in LABELS[channel]:
            loc = section.get_by_text(label,exact=True)
            matches = [loc.nth(i) for i in range(loc.count()) if loc.nth(i).is_visible()]
            if not matches:
                continue
            if len(matches) != 1:
                raise UnsupportedDOM('Multiple visible '+label+' cards; section cannot be safely scoped')
            card = matches[0].evaluate(CARD_JS,all_labels)
            if card is None:
                raise UnsupportedDOM('Unsupported metric card ancestor: '+label)
            cards.append(card)
        raw = scope_text('\n'.join(cards),channel)
        (folder/(channel+'.txt')).write_text(raw,encoding='utf-8')
        (folder/(channel+'-section.txt')).write_text(section.inner_text(),encoding='utf-8')
        metrics = extract_metrics(raw,target.country,channel)
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        screenshot = folder / (target.affiliate_id+'-'+stamp+'-'+channel+'.png')
        screenshot_status='saved'
        screenshot_error=None
        try:
            self.page.screenshot(path=str(screenshot),full_page=True,timeout=15000)
        except Exception as exc:
            screenshot_status='failed'
            screenshot_error=str(exc)[:500]
            screenshot=None
        (folder / (channel+'.txt')).write_text(raw,encoding='utf-8')
        return dict(status='ok',metrics=metrics,period=period,channel_evidence=selected,identity_evidence=identity,
                    page_updated_raw=updated[1],page_timezone='unknown',
                    collected_at=datetime.now(timezone.utc).isoformat(),source_url=self.page.url,
                    screenshot=str(screenshot) if screenshot else None,
                    screenshot_status=screenshot_status,screenshot_error=screenshot_error, raw_text=str(folder/(channel+'.txt')),
                    visible_section_raw=section.inner_text())


_runtime=globals().get('_runtime',threading.local())

def shared_playwright():
    if not getattr(_runtime,'pw',None):
        from playwright.sync_api import sync_playwright
        _runtime.pw=sync_playwright().start()
    return _runtime.pw


class ExistingChromeSession:
    """Own only newly-created Shopee tabs; never close the user's context.

    For CDP-attached browsers Browser.close disconnects the transport (the
    Playwright 1.64 driver implementation was inspected), not Chrome itself.
    """
    def __init__(self,browser,context,disconnect=True):
        self.browser=browser
        self.disconnect=disconnect
        self.context=context
        self.pages=[]
        self.new_page()

    def new_page(self):
        page=self.context.new_page()
        self.pages.append(page)
        return page

    def close(self):
        for page in self.pages:
            try:
                if not page.is_closed():page.close()
            except Exception:pass
        if self.disconnect:
            try:self.browser.close()
            except Exception:pass


def launch(pw,data_dir,country):
    # Attach by official channel-name discovery to the Chrome the user has
    # already started. Never launch a replacement or copy their profile.
    keep=os.environ.get('SHOPEE_TRACKER_KEEP_BROWSER')=='1'
    cached=getattr(_runtime,'browser',None)if getattr(_runtime,'owner',None)is pw else None
    try:
        browser=cached if keep and cached and cached.is_connected()else pw.chromium.connect_over_cdp('chrome',no_defaults=True,timeout=120000)
    except Exception:
        raise RuntimeError('existing_chrome_connection_required: 请在你日常使用的 Chrome 中允许本机连接，并在 Chrome 提示时确认；工具没有创建新浏览器或登录档案。')from None
    if not browser.contexts:
        browser.close()
        raise RuntimeError('existing_chrome_connection_required: 未发现现有 Chrome 档案，请打开日常使用的 Chrome 后重试。')
    if keep:_runtime.browser=browser;_runtime.owner=pw
    try:return ExistingChromeSession(browser,browser.contexts[0],disconnect=not keep)
    except Exception:
        browser.close()
        raise
