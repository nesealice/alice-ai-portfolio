import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import sys
from zoneinfo import ZoneInfo
from .core import CHANNELS, DOMAINS, Store, UnsupportedDOM, load_targets
from .export import export_results

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = Path.home() / 'Library' / 'Application Support' / 'ShopeeTrackerPublic'


def today():
    return datetime.now(ZoneInfo('Asia/Shanghai')).date().isoformat()


@contextmanager
def exclusive(data):
    data.mkdir(parents=True,exist_ok=True)
    os.chmod(data,0o700)
    with (data/'process.lock').open('a') as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('Another Shopee Tracker process is using this data directory. Close it first.')
        try:
            yield
        finally:
            fcntl.flock(lock,fcntl.LOCK_UN)


@contextmanager
def browser_session(data):
    os.environ.setdefault('PLAYWRIGHT_BROWSERS_PATH',str(data/'browsers'))
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise ValueError('Playwright is not installed. Run Setup.command first.')
    if os.environ.get('SHOPEE_TRACKER_KEEP_BROWSER')=='1':
        from .browser import shared_playwright
        yield shared_playwright()
    else:
        with sync_playwright()as pw:yield pw


def wait_for_manual(page,target,seconds=600):
    """Keep the visible browser open; no CAPTCHA/password automation."""
    from .browser import detect_blocker, VisibleAdapter
    import time
    deadline=time.monotonic()+seconds
    print('Waiting for the account holder to finish login / verification in the visible browser (up to 10 min).',flush=True)
    while time.monotonic()<deadline:
        if page.is_closed():
            raise ValueError('Browser closed before access was verified; login state remains local')
        try:
            text=page.locator('body').inner_text(timeout=3000)
            if not detect_blocker(page.url,text):
                # Seller Centre may return to the homepage after authentication.
                if '/portal' in page.url and 'kol_marketplace/detail' not in page.url:
                    page.goto(target.url,wait_until='domcontentloaded',timeout=30000)
                    continue
                VisibleAdapter(page).verify_target(target,text)
                if 'Sales Metrics' in text:
                    return
        except Exception:
            pass
        page.wait_for_timeout(1500)
    raise ValueError('Manual login/verification timed out; use login or resume later. Saved results are preserved.')


def login(data,interactive=False):
    from .browser import launch
    from .config import configured_targets
    target=configured_targets(data)[0]
    with browser_session(data) as pw:
        context=launch(pw,data,'ID')
        try:
            page=context.pages[0] if context.pages else context.new_page()
            page.goto(target.url,wait_until='domcontentloaded',timeout=45000)
            print('In the browser, the account holder enters password / CAPTCHA manually.',flush=True)
            if interactive:
                input('After Seller Centre is accessible, press Enter here: ')
            wait_for_manual(page,target)
        finally:
            context.close()
    print('ID profile saved locally; first target identity and Sales Metrics are visible. Other targets are verified during collection.')


def collect(data, store, run, interactive=True,on_complete=None):
    from .browser import VisibleAdapter, launch
    record = store.run(run)
    if record['date'] != today():
        raise ValueError('Cannot resume an older date with new data. Start collect for today; old results remain exportable.')
    selectors_file = data/'selectors.json'
    selectors = json.loads(selectors_file.read_text()) if selectors_file.exists() else {}
    with browser_session(data) as pw:
        context = launch(pw,data,'ID')
        try:
            page = context.pages[0] if context.pages else context.new_page()
            from .status import mark
            def completed(target):
                mark(store,run,target,'extraction','done')
                if on_complete:on_complete(target)
            # Retry browser failures first; recheck completed creators' cloud
            # records afterwards instead of delaying useful collection work.
            ordered=sorted(record['targets'],key=lambda t:not bool(store.pending(run,t)))
            for i,target in enumerate(ordered,1):
                pending = store.pending(run,target)
                if not pending:
                    completed(target)
                    continue
                mark(store,run,target,'extraction','running')
                print('[%s/%s] %s (%s)'%(i,len(record['targets']),target.shopee_handle,', '.join(pending)),flush=True)
                folder = data/'evidence'/run/target.affiliate_id
                folder.mkdir(parents=True,exist_ok=True)
                adapter = VisibleAdapter(page,selectors)
                try:
                    page.goto(target.url,wait_until='domcontentloaded',timeout=45000)
                    adapter.wait_ready()
                    adapter.set_period()
                except Exception as exc:
                    for channel in pending:
                        _save_failure(store,run,target,channel,exc,page,folder)
                    print('Needs attention: %s'%exc,flush=True)
                    if 'verification_unavailable' in str(exc) or page.is_closed():
                        completed(target)
                        print('平台验证暂不可用或浏览器已关闭，已暂停剩余达人；请稍后继续。',flush=True)
                        break
                    if interactive:
                        choice = input('Complete login/verification in browser, then Enter to retry this creator; s to skip, q to pause: ').strip().lower()
                        if choice == 'q':
                            completed(target)
                            return
                        if choice != 's':
                            try:
                                adapter.wait_ready()
                                adapter.set_period()
                            except Exception as retry_exc:
                                print('Still blocked: %s. Saved; use resume later.'%retry_exc)
                                completed(target)
                                continue
                        else:
                            completed(target)
                            continue
                    else:
                        if any(state in str(exc) for state in ('login_required','verification_required')):
                            try:
                                wait_for_manual(page,target)
                                adapter.set_period()
                            except Exception as manual_exc:
                                print(str(manual_exc),flush=True)
                                completed(target)
                                break
                        else:
                            completed(target)
                            # A shared loading failure should not trigger 15 blind navigations.
                            if 'loading_timeout' in str(exc):break
                            continue
                stop_batch=False
                for channel in pending:
                    try:
                        payload = adapter.read(target,channel,folder)
                        if today() != record['date']:
                            raise UnsupportedDOM('Date changed during collection; create a new daily run')
                        store.save(run,target,channel,payload)
                        print('  '+channel+': saved',flush=True)
                    except Exception as exc:
                        _save_failure(store,run,target,channel,exc,page,folder)
                        print('  '+channel+': '+str(exc),flush=True)
                        if any(s in str(exc)for s in ('verification_unavailable','verification_required','login_required'))or page.is_closed():
                            stop_batch=True
                            for remaining in pending[pending.index(channel)+1:]:
                                _save_failure(store,run,target,remaining,exc,page,folder)
                            break
                completed(target)
                if stop_batch:break
                if page.is_closed():break
                page.wait_for_timeout(2000)
        finally:
            context.close()


def _save_failure(store,run,target,channel,exc,page,folder):
    message = str(exc)[:800]
    status = next((s for s in ('channel_not_offered','verification_unavailable','login_required','verification_required','no_permission','loading_timeout') if s in message),'unsupported_dom' if isinstance(exc,UnsupportedDOM) else 'collection_failed')
    screenshot = folder/(target.affiliate_id+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+channel+'-failure.png')
    try:
        page.screenshot(path=str(screenshot),full_page=True,timeout=5000)
    except Exception:
        screenshot = None
    store.save(run,target,channel,dict(status=status,error=message,
        collected_at=datetime.now(timezone.utc).isoformat(),source_url=target.url,
        screenshot=str(screenshot) if screenshot else None))


def run_pipeline(data,store,run,config,interactive=False):
    """Each creator completion persists locally, then syncs before the next one."""
    from .status import mark
    from .output import writeback
    # The command holds the process lock; any previous running marker belongs
    # to an interrupted invocation rather than another active worker.
    with store.db:
        store.db.execute('CREATE TABLE IF NOT EXISTS progress(run TEXT,country TEXT,affiliate TEXT,phase TEXT,state TEXT,detail TEXT,record_id TEXT,PRIMARY KEY(run,country,affiliate,phase))')
        store.db.execute("UPDATE progress SET state='pending' WHERE run=? AND state='running'",(run,))
    def sync(target):
        rows=[r for r in store.results(run)if r['target']['country']==target.country and r['target']['affiliate_id']==target.affiliate_id]
        if not any(r.get('status')=='ok'and r.get('metrics')for r in rows):
            mark(store,run,target,'writeback','blocked','没有已核实数据，未创建空记录')
            return
        try:
            writeback(store,run,config,only_targets=[target],raise_failures=False)
        except Exception as exc:
            mark(store,run,target,'writeback','failed',str(exc))
            print('输出失败，原始数据已保存：'+str(exc),flush=True)
    collect(data,store,run,interactive,on_complete=sync)
    prefix=data/'exports'/run
    print('\n'.join(export_results(store.results(run),prefix)),flush=True)
    return run


def pipeline_exit(store,run,targets,config=None):
    if any(store.pending(run,t)for t in targets):return 2
    rows=store.db.execute("SELECT state FROM progress WHERE run=? AND phase='writeback'",(run,)).fetchall()
    if len(rows)!=len(targets)or any(r[0]!='success'for r in rows):return 2
    if config:
        from .config import destination_key
        tables={x[0]for x in store.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'output_destinations'in tables:
            destinations=dict(store.db.execute('SELECT snapshot_key,destination FROM output_destinations'));date=store.run(run)['date']
            if any(destinations.get('snapshot:%s:%s:%s'%(t.country,t.affiliate_id,date))!=destination_key(config)for t in targets):return 2
        from .config import output_mode
        if output_mode(config)=='excel':return 0
    mode='app'
    if config and Path(config).exists():mode=json.loads(Path(config).read_text()).get('screenshot_upload_mode','app')
    if mode not in ('app','app-http','lark-cli-user'):return 0
    from .status import proof_complete
    tables={x[0]for x in store.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if 'attachment_uploads'not in tables:return 2
    proofs={key:(state,json.loads(details))for key,state,details in store.db.execute('SELECT snapshot_key,state,details FROM attachment_uploads')}
    date=store.run(run)['date'];results=store.results(run)
    for target in targets:
        state,details=proofs.get('snapshot:%s:%s:%s'%(target.country,target.affiliate_id,date),('pending',{}))
        current=[r for r in results if r['target']['country']==target.country and r['target']['affiliate_id']==target.affiliate_id]
        if not proof_complete(current,state,details):return 2
    return 0


def parser():
    p = argparse.ArgumentParser(description='Shopee Indonesia: configurable creators, local Excel or your own Feishu Base; no AI calls.')
    p.add_argument('--data-dir',type=Path,default=DEFAULT_DATA,help='Private local profile/state directory')
    sub = p.add_subparsers(dest='command',required=True)
    l = sub.add_parser('login',help='Open ID browser for account holder login; waits up to 10 min')
    l.add_argument('--interactive',action='store_true',help='Ask for Enter in this terminal before verification')
    sub.add_parser('targets',help='Preview the fixed Indonesian target list')
    c = sub.add_parser('collect',help="Start today's configured Indonesian creator task")
    c.add_argument('--config',type=Path,default=None)
    c.add_argument('--interactive',action='store_true')
    c.add_argument('--non-interactive',action='store_true',help=argparse.SUPPRESS)
    r = sub.add_parser('resume',help='Retry only failed/missing channels of today’s task')
    r.add_argument('--run',default='latest')
    r.add_argument('--config',type=Path,default=None)
    r.add_argument('--interactive',action='store_true')
    r.add_argument('--non-interactive',action='store_true',help=argparse.SUPPRESS)
    e = sub.add_parser('export',help='Export JSON and CSV, including failures and ranges')
    e.add_argument('--run',default='latest')
    e.add_argument('--output',type=Path,required=True)
    s = sub.add_parser('status',help='Show task and channel progress')
    s.add_argument('--run',default='latest')
    w = sub.add_parser('writeback',help='Write verified snapshots to configured Feishu Base')
    w.add_argument('--run',default='latest')
    w.add_argument('--config',type=Path,default=None)
    w.add_argument('--preview',action='store_true',help='Show exact records without contacting Feishu')
    d = sub.add_parser('daily',help='One daily collection with same-day resume and optional writeback')
    d.add_argument('--config',type=Path,default=None)
    sched = sub.add_parser('schedule',help='Write a launchd plist; daily runs need logged-in awake Mac')
    sched.add_argument('--at',default='10:00')
    sched.add_argument('--config',type=Path)
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    args.data_dir = args.data_dir.expanduser().resolve()
    try:
        with exclusive(args.data_dir):
            if args.command == 'login':
                login(args.data_dir,args.interactive)
                return 0
            from .config import configured_targets
            targets = configured_targets(args.data_dir)
            if args.command == 'targets':
                for target in targets:
                    print(target.shopee_handle+'  '+target.url)
                return 0
            if args.command == 'schedule':
                from .schedule import write_schedule
                print(write_schedule(args.data_dir,args.at,args.config))
                return 0
            store = Store(args.data_dir/'state.sqlite')
            try:
                if args.command in ('collect','daily'):
                    run = None
                    if args.command in ('daily','collect'):
                        try:
                            last = store.latest()
                            if store.run(last)['date'] == today():
                                from dataclasses import asdict
                                if [asdict(t)for t in store.run(last)['targets']]!=[asdict(t)for t in targets]:
                                    raise ValueError('今天已开始采集，修改后的达人名单明天生效；请先恢复今天的名单以继续任务')
                                run = last
                        except ValueError as exc:
                            if 'No saved run'not in str(exc)and 'No runs'not in str(exc):raise
                    run = run or store.new_run(targets,today())
                    print('Run: '+run,flush=True)
                    run_pipeline(args.data_dir,store,run,args.config or args.data_dir/'base-config.json',args.command!='daily' and args.interactive)
                    print('Collection finished. Review status for any channels that need attention.')
                    return pipeline_exit(store,run,targets,args.config or args.data_dir/'base-config.json')
                run = store.latest() if args.run == 'latest' else args.run
                if args.command == 'resume':
                    run_pipeline(args.data_dir,store,run,args.config or args.data_dir/'base-config.json',args.interactive)
                    return pipeline_exit(store,run,store.run(run)['targets'],args.config or args.data_dir/'base-config.json')
                if args.command == 'export':
                    print('\n'.join(export_results(store.results(run),args.output)))
                elif args.command == 'status':
                    record = store.run(run)
                    print('Run: %s | Date: %s | Last 7 Days rolling snapshot'%(run,record['date']))
                    for target in record['targets']:
                        pending=store.pending(run,target)
                        print(target.shopee_handle+': '+('complete' if not pending else 'retry '+', '.join(pending)))
                elif args.command == 'writeback':
                    from .output import writeback
                    config = args.config or args.data_dir/'base-config.json'
                    writeback(store,run,config,preview=args.preview)
                    if not args.preview:return pipeline_exit(store,run,store.run(run)['targets'],config)
            finally:
                store.close()
    except (ValueError, OSError, RuntimeError) as exc:
        print('Error: '+str(exc),file=sys.stderr)
        return 1
    return 0
