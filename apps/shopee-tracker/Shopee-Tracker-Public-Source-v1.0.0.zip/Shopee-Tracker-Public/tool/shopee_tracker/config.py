"""Public configuration: no personal defaults or bundled account state."""
import json
from pathlib import Path
from .core import load_targets

def read_config(path):
 p=Path(path)
 config=json.loads(p.read_text())if p.exists()else {'output':'excel','screenshot_upload_mode':'local-only'}
 if config.get('output','excel')not in ('excel','feishu'):raise ValueError('输出请选择 Excel 或飞书多维表')
 return config

def configured_targets(data):
 path=Path(data)/'targets.csv'
 if not path.exists():raise ValueError('请先在设置中添加需要采集的印尼达人链接')
 try:targets=load_targets(path)
 except ValueError as exc:
  if 'No valid targets'in str(exc):raise ValueError('请先在设置中添加需要采集的印尼达人链接')from None
  raise
 if not targets:raise ValueError('请先在设置中添加需要采集的印尼达人链接')
 if any(t.country!='ID'for t in targets):raise ValueError('当前公开版仅支持印尼站达人')
 return targets

def output_mode(path):return read_config(path).get('output','excel')

def destination_key(config_path):
 from hashlib import sha256
 c=read_config(config_path);mode=c.get('output','excel')
 if mode=='excel':
  p=Path(c.get('excel_path')or Path(config_path).parent/'exports/tracking.xlsx').expanduser()
  if not p.is_absolute():p=Path(config_path).parent/p
  identity=[mode,str(p.resolve())]
 else:identity=[mode,c.get('api_origin','https://open.feishu.cn'),c.get('base_token'),c.get('snapshot_table_id',c.get('snapshots_table_id'))]
 return sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
