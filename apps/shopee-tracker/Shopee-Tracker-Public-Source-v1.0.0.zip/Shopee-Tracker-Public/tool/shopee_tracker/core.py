import csv
import json
import re
import sqlite3
import uuid
from dataclasses import dataclass, asdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

CHANNELS = ('sales', 'live', 'video')
DOMAINS = {'ID': 'seller.shopee.co.id', 'TH': 'seller.shopee.co.th'}
DETAIL_PATH = '/portal/web-seller-affiliate/kol_marketplace/detail'
LABELS = {
    'sales': ('Clicks', 'Items Sold', 'Orders', 'GMV(Rp)', 'GMV(฿)', 'GMV', 'ROI'),
    'live': ('Livestream Session', 'Views', 'Likes', 'Comments', 'GPM(Rp)', 'GPM(฿)', 'GPM'),
    'video': ('Video Post','Video', 'Videos', 'Video Published', 'Videos Published', 'Published Videos', 'Views', 'Likes', 'Comments', 'GPM(Rp)', 'GPM(฿)', 'GPM'),
}

class UnsupportedDOM(RuntimeError):
    pass

@dataclass
class Target:
    country: str
    affiliate_id: str
    shopee_handle: str
    url: str
    source_rows: list
    source_sheet: str = ''
    category: str = ''
    tts_link: str = ''


def validate_url(url):
    p = urlsplit(url)
    country = next((c for c, host in DOMAINS.items() if host == p.hostname), None)
    ids = parse_qs(p.query).get('affiliate_id', [])
    if (p.scheme != 'https' or not country or p.netloc != DOMAINS[country]
            or p.path != DETAIL_PATH or len(ids) != 1 or not ids[0].isdigit() or p.fragment):
        raise ValueError('Only official ID/TH detail HTTPS URLs with one numeric affiliate_id are allowed')
    return country, ids[0]


def load_targets(path):
    result = {}
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        for i, row in enumerate(csv.DictReader(stream), 2):
            url = (row.get('url') or '').strip()
            country, affiliate = validate_url(url)
            if row.get('country', country).strip().upper() != country:
                raise ValueError('Country mismatch at CSV row %s' % i)
            if row.get('affiliate_id', affiliate).strip() != affiliate:
                raise ValueError('affiliate_id mismatch at CSV row %s' % i)
            handle = (row.get('shopee_handle') or '').strip().lstrip('@')
            if not handle:
                raise ValueError('Exact shopee_handle is required at CSV row %s' % i)
            key = country, affiliate
            rows = [x for x in (row.get('source_rows') or '').split(';') if x]
            if key in result:
                if result[key].shopee_handle != handle:
                    raise ValueError('Conflicting usernames for %s' % affiliate)
                result[key].source_rows = list(dict.fromkeys(result[key].source_rows + rows))
            else:
                result[key] = Target(country, affiliate, handle, url, rows,
                                     row.get('source_sheet', ''), row.get('category', ''), row.get('tts_link', ''))
    if not result:
        raise ValueError('No valid targets in CSV')
    return list(result.values())


def verify_identity(target, current_url, visible_text):
    if validate_url(current_url) != (target.country, target.affiliate_id):
        raise UnsupportedDOM('Identity mismatch: current URL differs from target')
    if target.shopee_handle not in [x.strip().lstrip('@') for x in visible_text.splitlines()]:
        raise UnsupportedDOM('Exact displayed username not found; refusing identity inference')


def parse_number(raw, country, label=''):
    text = raw.strip()
    currency = 'IDR' if 'Rp' in text + label else 'THB' if ('฿' in text + label or 'THB' in text + label) else None
    out = dict(raw=raw, value=None, lower=None, upper=None, operator=None,
               currency=currency, unit=None, status='unknown')
    if text.lower() in ('', '-', '--', '—', '–', 'no data', 'tidak ada data', 'n/a', 'ไม่มีข้อมูล'):
        out['status'] = 'missing'
        return out
    text = re.sub(r'(?i)Rp|THB|฿', '', text).strip()
    op = re.match(r'^(>=|<=|≥|≤|>|<|~|≈)', text)
    if op:
        out['operator'] = op[0]
        text = text[len(op[0]):].strip()
    percent = text.endswith('%')
    if percent:
        text = text[:-1].strip()
        out['unit'] = 'percent'
    units = {'RB': Decimal(1000), 'JT': Decimal(1000000), 'M': Decimal(1000000000)} if country == 'ID' else {}
    def scalar(part):
        part = part.strip()
        unit = re.search(r'([A-Za-z]+)$', part)
        factor = Decimal(1)
        if unit:
            suffix = unit[1].upper()
            if suffix not in units:
                raise LookupError(suffix)
            factor = units[suffix]
            part = part[:unit.start()].strip()
        # Group separators are validated rather than silently guessed.
        if country == 'ID':
            if not re.fullmatch(r'[+-]?(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d+)?', part):
                raise InvalidOperation()
            part = part.replace('.', '').replace(',', '.')
        else:
            if not re.fullmatch(r'[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?', part):
                raise InvalidOperation()
            part = part.replace(',', '')
        return format(Decimal(part) * factor, 'f')
    try:
        split = re.split(r'(?<=[0-9A-Za-z])\s*[-–—]\s*(?=[0-9])',text)
        if len(split) == 2:
            out['lower'], out['upper'] = map(scalar, split)
            if Decimal(out['lower']) > Decimal(out['upper']):
                raise InvalidOperation()
            out['status'] = 'range'
        elif len(split) == 1:
            value = scalar(text)
            operator = out['operator']
            if operator in ('>', '>=', '≥'):
                out['lower'], out['status'] = value, 'bound'
            elif operator in ('<', '<=', '≤'):
                out['upper'], out['status'] = value, 'bound'
            else:
                out['value'], out['status'] = value, 'approximate' if operator else 'numeric'
        else:
            raise InvalidOperation()
    except LookupError:
        out['status'] = 'unknown_unit'
    except (InvalidOperation, ValueError):
        out.update(value=None, lower=None, upper=None, status='unknown')
    return out


def extract_metrics(text, country, channel):
    """Parse only a separately scoped visible channel block, never a whole page."""
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    labels = LABELS[channel]
    metrics = {}
    for i, line in enumerate(lines):
        if line not in labels:
            continue
        if line in metrics:
            raise UnsupportedDOM('Ambiguous duplicate metric: ' + line)
        if i + 1 >= len(lines) or lines[i+1] in labels or lines[i+1].startswith('vs '):
            raise UnsupportedDOM('Metric label without adjacent value: ' + line)
        raw = lines[i+1]
        if i+2 < len(lines) and lines[i+2].upper() in ('RB','JT','M'):
            raw += lines[i+2]
        metrics[line] = parse_number(raw, country, line)
        if i+2 < len(lines) and re.match(r'(?i)^vs\s', lines[i+2]):
            metrics[line]['comparison_raw'] = lines[i+2]
            metrics[line]['comparison_direction'] = 'unknown'
    if not metrics:
        raise UnsupportedDOM('No supported metric labels in scoped channel block')
    if any(x['status'] == 'unknown' for x in metrics.values()):
        raise UnsupportedDOM('Metric layout/value unsupported; raw evidence retained')
    # Expected common fields are explicitly absent, never zero.
    for label in (('Clicks','Items Sold','Orders','ROI') if channel == 'sales' else ('Views','Likes','Comments')):
        metrics.setdefault(label, dict(raw=None, value=None, lower=None, upper=None,
                                       operator=None, currency=None, unit=None, status='not_displayed'))
    return metrics


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS runs (id TEXT PRIMARY KEY, date TEXT, targets TEXT, period TEXT);
        CREATE TABLE IF NOT EXISTS snapshots (run TEXT,country TEXT,affiliate TEXT,channel TEXT,payload TEXT,
        PRIMARY KEY(run,country,affiliate,channel));
        CREATE TABLE IF NOT EXISTS writebacks (snapshot_key TEXT PRIMARY KEY,record_id TEXT,payload TEXT);
        ''')
        self.db.commit()

    def new_run(self, targets, date):
        run = str(uuid.uuid4())
        with self.db:
            self.db.execute('INSERT INTO runs VALUES(?,?,?,?)',
                            (run,date,json.dumps([asdict(t) for t in targets]),'Last 7 Days'))
        return run

    def run(self, run):
        row = self.db.execute('SELECT date, targets, period FROM runs WHERE id=?',(run,)).fetchone()
        if not row:
            raise ValueError('Unknown run ID')
        return {'id':run,'date':row[0],'targets':[Target(**t) for t in json.loads(row[1])], 'period':row[2]}

    def latest(self):
        row = self.db.execute('SELECT id FROM runs ORDER BY rowid DESC LIMIT 1').fetchone()
        if not row:
            raise ValueError('No runs; use collect first')
        return row[0]

    def save(self, run, target, channel, payload):
        payload = dict(payload, run_id=run, channel=channel, target=asdict(target))
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO snapshots VALUES(?,?,?,?,?)',
                            (run,target.country,target.affiliate_id,channel,json.dumps(payload,ensure_ascii=False)))

    def results(self, run):
        return [json.loads(row[0]) for row in self.db.execute('SELECT payload FROM snapshots WHERE run=? ORDER BY country,affiliate,channel',(run,))]

    def pending(self, run, target):
        done = {json.loads(r[0])['channel'] for r in self.db.execute(
            'SELECT payload FROM snapshots WHERE run=? AND country=? AND affiliate=?',
            (run,target.country,target.affiliate_id)) if json.loads(r[0]).get('status') in ('ok','channel_not_offered')}
        return [c for c in CHANNELS if c not in done]

    def close(self):
        self.db.close()
