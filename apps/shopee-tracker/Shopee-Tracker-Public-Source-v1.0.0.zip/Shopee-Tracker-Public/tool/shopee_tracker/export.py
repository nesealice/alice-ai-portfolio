import csv
import json
from pathlib import Path

SEMANTICS = 'Recent 7 days rolling snapshot; overlapping windows, not daily GMV. Live Views is total views, not per-session average.'


def export_results(results, prefix):
    prefix = Path(prefix)
    prefix.parent.mkdir(parents=True,exist_ok=True)
    prefix.with_suffix('.json').write_text(json.dumps({'semantics':SEMANTICS,'results':results},ensure_ascii=False,indent=2),encoding='utf-8')
    columns = ['run_id','country','affiliate_id','shopee_handle','channel','channel_status','collected_at',
               'period','page_updated_raw','label','raw','value','lower','upper','operator','currency',
               'unit','status','comparison_raw','comparison_direction','source_url','screenshot','error']
    def safe(value):
        if value is None:
            return ''
        text = str(value)
        return "'" + text if text.startswith(('=','+','-','@','\t','\r')) else text
    with prefix.with_suffix('.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer = csv.DictWriter(stream,fieldnames=columns)
        writer.writeheader()
        for result in results:
            target = result['target']
            base = {k:result.get(k) for k in ('run_id','channel','collected_at','page_updated_raw','source_url','screenshot','error')}
            base.update({k:target.get(k) for k in ('country','affiliate_id','shopee_handle')})
            period = result.get('period',{})
            base.update(channel_status=result['status'],period=period.get('selected') if isinstance(period,dict) else period)
            for label, metric in (result.get('metrics') or {'':{}}).items():
                row = dict(base, label=label, **metric)
                writer.writerow({k:safe(row.get(k)) for k in columns})
    return [str(prefix.with_suffix('.json')),str(prefix.with_suffix('.csv'))]
