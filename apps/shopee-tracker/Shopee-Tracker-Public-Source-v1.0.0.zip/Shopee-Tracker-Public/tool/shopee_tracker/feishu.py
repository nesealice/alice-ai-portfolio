"""Standalone Feishu Base v3 HTTP client. Never reads lark-cli credentials.

Wire shapes follow the installed official lark-cli's inspected v3 contract,
including columnar record matrices. Actual app read/create/update and readback
were verified on 2026-10-23; see the release verification report.
"""
from datetime import datetime
import json
import os
from pathlib import Path
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, build_opener, HTTPRedirectHandler
from zoneinfo import ZoneInfo


class FeishuError(RuntimeError):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise FeishuError('Unexpected HTTP redirect from Feishu API')


def decode_matrix(data):
    fields = data.get('fields')
    rows = data.get('data')
    ids = data.get('record_id_list')
    if not isinstance(fields,list) or not isinstance(rows,list) or not isinstance(ids,list) or len(ids) != len(rows):
        raise FeishuError('Unsupported Base v3 matrix response')
    if len(set(fields)) != len(fields) or not all(isinstance(f,str) for f in fields):
        raise FeishuError('Ambiguous Base field schema')
    if any(not isinstance(row,list) or len(row) != len(fields) for row in rows):
        raise FeishuError('Base row/column counts differ')
    return [{'record_id':rid,'fields':dict(zip(fields,row))} for rid,row in zip(ids,rows)]


def exact(metrics,label):
    metric = metrics.get(label,{})
    if metric.get('status') != 'numeric' or metric.get('value') is None:
        return None
    # IEEE double is the Base number field representation; full decimal string
    # remains available in Raw Metrics JSON and the local JSON export.
    value=float(metric['value'])
    return int(value) if value.is_integer() else value


def build_fields(results,date,creator_id):
    channels = {r['channel']:r for r in results}
    if len(channels)!=len(results) or any(c not in ('sales','live','video') for c in channels):
        raise FeishuError('Duplicate or unknown channels')
    successful={c:r for c,r in channels.items() if r.get('status')=='ok' and r.get('metrics')}
    if not successful:
        raise FeishuError('No verified channel data; no empty Base record created')
    if any(r.get('period',{}).get('selected')!='Last 7 Days' for r in successful.values()):
        raise FeishuError('Unverified seven-day period')
    target=next(iter(successful.values()))['target']
    if any(r['target']['affiliate_id']!=target['affiliate_id'] or r['target']['country']!=target['country'] for r in channels.values()):
        raise FeishuError('Mixed target identity in snapshot')
    for result in successful.values():
        captured=datetime.fromisoformat(result['collected_at']).astimezone(ZoneInfo('Asia/Shanghai')).date().isoformat()
        if captured!=date:raise FeishuError('Capture date differs from task date')
    country=target['country'];affiliate=target['affiliate_id']
    sales=successful.get('sales',{}).get('metrics',{});live=successful.get('live',{}).get('metrics',{});video=successful.get('video',{}).get('metrics',{})
    latest=max(r['collected_at'] for r in successful.values())
    from .status import CHANNEL_NAMES,friendly_error
    missing=[CHANNEL_NAMES[c] for c in ('sales','live','video') if c not in successful]
    notes='最近7天滚动快照；直播Views为总观看次数；窗口变化不等于当天GMV。'
    renamed={r.get('identity_evidence',{}).get('observed_handle')for r in successful.values()if r.get('identity_evidence',{}).get('handle_changed')}
    if renamed:notes+='官方链接affiliate_id已核对；原表Handle保持不变，当前页面Handle：'+','.join(sorted(renamed))+'。'
    if missing:notes+='未提取成功：'+','.join(missing)+'；成功渠道已写入，其他字段保持空白。'
    for c,r in channels.items():
        if c not in successful:notes+=CHANNEL_NAMES[c]+'：'+friendly_error(r.get('error',''))+'。'
    fields={'Record Key':'snapshot:%s:%s:%s'%(country,affiliate,date),
            'Country':[country],'Affiliate ID':affiliate,
            'SHP Handle Name':target['shopee_handle'],'TTS Handle name':target.get('tts_link',''),
            'Category tag':target.get('category',''),'Date of Tracking':date,
            'Currency':['IDR' if country=='ID' else 'THB'],'Source':['自动采集'],
            'Record Status':['成功' if len(successful)==3 else '部分成功'],'Date Check':['正常'],
            'SHP KOL Link':target['url'],
            'Captured At':datetime.fromisoformat(latest).astimezone(ZoneInfo('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M:%S'),
            'Platform Updated At':successful.get('live',next(iter(successful.values()))).get('page_updated_raw',''),
            'Period':'Last 7 Days (rolling snapshot; not daily incremental)',
            'Raw Metrics JSON':json.dumps([channels[c]for c in sorted(channels)],ensure_ascii=False),
            'Screenshot Status':'已保存本机数据截图 %d 张；飞书附件以上传结果为准'%sum(bool(r.get('screenshot')) for r in successful.values()),
            }
    if creator_id:fields['Creator']=[{'id':creator_id}]
    numeric={
        '#of live session in last 7 days':exact(live,'Livestream Session'),
        'Average Page Views(PV) in last 7 days':exact(live,'Views'),
        'Sales revenue per 1000 PV in last 7 days':exact(live,'GPM(Rp)' if country=='ID' else 'GPM(฿)'),
        'Overall Clicks':exact(sales,'Clicks'),'Overall ROI':exact(sales,'ROI'),
        'Live Likes':exact(live,'Likes'),'Live Comments':exact(live,'Comments'),
        'Video Views':exact(video,'Views'),'Video Likes':exact(video,'Likes'),
        'Video Comments':exact(video,'Comments'),'Video GPM':exact(video,'GPM(Rp)' if country=='ID' else 'GPM(฿)')}
    for label in ('Video Post','Videos Published','Published Videos','Video Published','Videos','Video'):
        if label in video:
            numeric['Video Count']=exact(video,label)
            break
    fields.update({k:v for k,v in numeric.items() if v is not None})
    fields.update({'Overall GMV Raw':sales.get('GMV(Rp)' if country=='ID' else 'GMV(฿)',sales.get('GMV',{})).get('raw') or '',
                   'Overall Orders Raw':sales.get('Orders',{}).get('raw') or '',
                   'Overall Items Sold Raw':sales.get('Items Sold',{}).get('raw') or ''})
    return fields


def _cell(value):
    # Base normalizes cleared text cells to null on readback. Keep numeric 0
    # and false distinct from a blank value.
    if value=='':return None
    if isinstance(value,list) and len(value)==1:
        return _cell(value[0])
    if isinstance(value,dict) and set(value)=={'value'}:
        return _cell(value['value'])
    return value


def _date(value):
    value=_cell(value)
    if isinstance(value,(int,float)):
        return datetime.fromtimestamp(value/1000,ZoneInfo('Asia/Shanghai')).date().isoformat()
    return str(value)[:10]


def previous_fields(rows,fields):
    candidates=[]
    current_date=_date(fields.get('Date of Tracking'))
    if not re_full_date(current_date):return {}
    for row in rows:
        f=row['fields']
        date=_date(f.get('Date of Tracking'))
        period=_cell(f.get('Period')) or ''
        if (_cell(f.get('Affiliate ID'))==fields['Affiliate ID']
            and _cell(f.get('Country'))==_cell(fields['Country'])
            and date<current_date and re_full_date(date)
            and ('Last 7 Days' in period or 'last 7 days' in period.lower() or '最近7天' in period)):
            candidates.append((date,f))
    if not candidates:
        return {}
    latest=max(x[0] for x in candidates)
    matches=[f for date,f in candidates if date==latest]
    # Ambiguous duplicate historical days do not supply a comparison baseline.
    if len(matches)!=1:
        return {}
    f=matches[0]
    out={}
    for old,new in [('#of live session in last 7 days','Previous Live Sessions'),
                    ('Average Page Views(PV) in last 7 days','Previous Live Views'),
                    ('Sales revenue per 1000 PV in last 7 days','Previous Live GPM')]:
        value=f.get(old)
        if isinstance(value,(int,float)) and not isinstance(value,bool):
            out[new]=value
    return out


def re_full_date(value):
    import re
    return bool(re.fullmatch(r'\d{4}-\d{2}-\d{2}',value))


def publish(client,fields):
    def locate():
        rows=client.records()
        matches=[r for r in rows if _cell(r['fields'].get('Record Key'))==fields['Record Key']]
        for row in rows:
            f=row['fields']
            if (_cell(f.get('Affiliate ID'))==fields.get('Affiliate ID') and _date(f.get('Date of Tracking'))==fields.get('Date of Tracking')
                and _cell(f.get('Country'))==_cell(fields.get('Country')) and row not in matches):
                raise FeishuError('Same-day identity conflict; review Base row '+row['record_id'])
        if len(matches)>1:raise FeishuError('Duplicate snapshot keys already exist in Base')
        if matches and _cell(matches[0]['fields'].get('Source'))!='自动采集':
            raise FeishuError('Existing key belongs to a non-tool record; refusing overwrite')
        return matches[0] if matches else None
    def equal(existing):
        for key,value in fields.items():
            if key in ('Captured At','Screenshot Status','Collection Notes','SHP KOL Link','Creator'):continue
            observed=existing.get(key)
            if key=='Date of Tracking':same=_date(observed)==value
            elif key=='Previous Tracking Date':same=_date(observed)==_date(value)
            else:same=_cell(observed)==_cell(value)
            if not same:return False
        return True
    def can_extend(existing):
        try:
            old=json.loads(_cell(existing.get('Raw Metrics JSON')) or '[]');new=json.loads(fields.get('Raw Metrics JSON','[]'))
        except (ValueError,TypeError):return False
        old_ok={r['channel']:r for r in old if r.get('status')=='ok'and r.get('metrics')}
        new_ok={r['channel']:r for r in new if r.get('status')=='ok'and r.get('metrics')}
        if not old_ok or not set(old_ok)<=set(new_ok):return False
        if set(old_ok)==set(new_ok):
            if old==new:return False
            metadata={'Raw Metrics JSON','Captured At','Screenshot Status','Collection Notes','Creator','SHP KOL Link'}
            for key,value in fields.items():
                if key in metadata:continue
                observed=existing.get(key)
                if key in ('Date of Tracking','Previous Tracking Date'):
                    if _date(observed)!=_date(value):return False
                elif _cell(observed)!=_cell(value):return False
        # A resume may only add channels within the same run; previously verified
        # payloads (identity, date, values and evidence) must remain identical.
        if any(new_ok.get(c)!=r for c,r in old_ok.items()):return False
        run_ids={r.get('run_id')for r in old_ok.values()}
        if len(run_ids)!=1 or None in run_ids or any(r.get('run_id')not in run_ids for r in new_ok.values()):return False
        return True
    found=locate()
    if found and equal(found['fields']):return found['record_id']
    if found and not can_extend(found['fields']):
        raise FeishuError('Existing snapshot differs; refusing overwrite of successful data')
    try:
        if found:client.update(found['record_id'],fields)
        else:client.create(fields)
    except (TimeoutError,URLError,HTTPError,FeishuError) as write_error:
        confirmed=locate()
        if confirmed and equal(confirmed['fields']):return confirmed['record_id']
        raise FeishuError('Write outcome not confirmed; no mutation retried. Local results preserved. Cause: '+str(write_error)) from None
    confirmed=locate()
    if not confirmed or not equal(confirmed['fields']):
        raise FeishuError('Write returned but snapshot readback did not match. Local results preserved.')
    return confirmed['record_id']


class Client:
    def __init__(self,config):
        self.origin=config.get('api_origin','https://open.feishu.cn')
        if self.origin not in ('https://open.feishu.cn','https://open.larksuite.com'):
            raise FeishuError('Only official Feishu/Lark API origins are allowed')
        self.config=config
        self.token=None
        self.expires=0
        self.opener=build_opener(NoRedirect())
        self.columns=None

    def ensure_token(self):
        if not self.token or time.time()>=self.expires:
            app_id=os.environ.get('FEISHU_APP_ID')
            secret=os.environ.get('FEISHU_APP_SECRET')
            if not app_id or not secret:
                raise FeishuError('Set local FEISHU_APP_ID and FEISHU_APP_SECRET for a separately authorized app. No CLI credentials are read.')
            data=self.request('POST','/open-apis/auth/v3/tenant_access_token/internal',{'app_id':app_id,'app_secret':secret},auth=False)
            self.token=data.get('tenant_access_token')
            if not self.token:
                raise FeishuError('Tenant token missing from auth response')
            self.expires=time.time()+int(data.get('expire',3600))-60
        return self.token

    def request(self,method,path,body=None,auth=True):
        if auth:self.ensure_token()
        headers={'Content-Type':'application/json; charset=utf-8'}
        if auth:
            headers['Authorization']='Bearer '+self.token
        request=Request(self.origin+path,data=json.dumps(body,ensure_ascii=False).encode() if body is not None else None,headers=headers,method=method)
        try:
            with self.opener.open(request,timeout=40) as response:
                payload=json.load(response)
        except HTTPError as exc:
            try:
                details=json.loads(exc.read(8192));reason=str(details.get('code',''))+': '+str(details.get('msg',''))[:250]
            except Exception:reason='No structured API error returned'
            for name in ('FEISHU_APP_SECRET','FEISHU_APP_ID'):
                if os.environ.get(name):reason=reason.replace(os.environ[name],'[redacted]')
            raise FeishuError('Feishu HTTP error %s (%s); endpoint=%s'%(exc.code,reason,'app_auth'if not auth else'Base'))from None
        if payload.get('code',0)!=0:
            raise FeishuError('Feishu API code '+str(payload['code'])+': '+str(payload.get('msg',''))[:200])
        return payload.get('data',payload)

    def path(self):
        return '/open-apis/base/v3/bases/%s/tables/%s/records'%(quote(self.config['base_token'],safe=''),quote(self.config.get('snapshot_table_id',self.config.get('snapshots_table_id')),safe=''))

    def records(self):
        records=[];offset=0
        while True:
            data=self.request('GET',self.path()+'?'+urlencode({'limit':100,'offset':offset}))
            batch=decode_matrix(data)
            self.columns=data['fields']
            records.extend(batch)
            if not data.get('has_more'):
                break
            if not batch or offset>100000:
                raise FeishuError('Base pagination did not progress or exceeded safety bound')
            offset+=len(batch)
        return records

    def create(self,fields):
        if self.columns is None:
            self.records()
        missing=set(fields)-set(self.columns)
        if missing:
            raise FeishuError('Base schema changed; missing fields: '+', '.join(sorted(missing)))
        return self.request('POST',self.path()+'/batch_create',{'create_records':[fields]})

    def update(self,record_id,fields):
        return self.request('POST',self.path()+'/batch_update',{'update_records':{record_id:fields}})


def writeback(store,run,config_path,preview=False,only_targets=None,raise_failures=True):
    config_path=Path(config_path)
    config=json.loads(config_path.read_text(encoding='utf-8'))
    mapping=config.get('creator_record_ids',config.get('creator_record_map'))
    if not isinstance(mapping,dict):
        map_file=config.get('creator_record_map_file')
        mapping=json.loads((config_path.parent/map_file).read_text())if map_file else{}
    record=store.run(run)
    results=store.results(run)
    client=None if preview else Client(config)
    failures=[]
    outcomes=[]
    from .status import mark
    for target in (only_targets if only_targets is not None else record['targets']):
        key=target.country+':'+target.affiliate_id
        rows=[r for r in results if r['target']['country']==target.country and r['target']['affiliate_id']==target.affiliate_id]
        if not any(r.get('status')=='ok'and r.get('metrics')for r in rows):
            if not preview:mark(store,run,target,'writeback','blocked','没有已核实的数据，未创建空记录')
            outcomes.append({'target':key,'state':'blocked'});continue
        try:
            if not preview:mark(store,run,target,'writeback','running')
            creator_id=mapping.get(key)
            rows=[r for r in results if r['target']['country']==target.country and r['target']['affiliate_id']==target.affiliate_id]
            fields=build_fields(rows,record['date'],creator_id)
            if preview:
                print(json.dumps(fields,ensure_ascii=False,indent=2))
            else:
                fields.update(previous_fields(client.records(),fields))
                rid=publish(client,fields)
                with store.db:
                    store.db.execute('INSERT OR REPLACE INTO writebacks VALUES(?,?,?)',(fields['Record Key'],rid,json.dumps(fields,ensure_ascii=False)))
                mark(store,run,target,'writeback','success','',rid)
                outcomes.append({'target':key,'state':'success','record_id':rid})
                print(target.shopee_handle+': verified Base record '+rid)
                from .attachments import upload_proofs,update_cloud_status
                proofs=upload_proofs(config,store,fields['Record Key'],rid,[r.get('screenshot') for r in rows if r.get('status')=='ok'],client)
                if config.get('screenshot_upload_mode','app') in ('app','app-http','lark-cli-user'):
                    status_updated=update_cloud_status(config,rid,proofs,client=client)
                    print('  screenshots: '+proofs['state']+(' (Base status updated)' if status_updated else ' (status update unconfirmed)'))
                else:
                    print('  screenshots: '+proofs['state'])
                with store.db:
                    store.db.execute('INSERT OR REPLACE INTO writebacks VALUES(?,?,?)',
                        (fields['Record Key'],rid,json.dumps(fields,ensure_ascii=False)))
        except (FeishuError,KeyError,OSError,ValueError,URLError,TimeoutError) as exc:
            if not preview:mark(store,run,target,'writeback','failed',str(exc))
            outcomes.append({'target':key,'state':'failed','error':str(exc)})
            failures.append(key+': '+str(exc))
            print('Writeback skipped '+failures[-1])
    if failures and not preview and raise_failures:
        raise FeishuError('%s creators not written. Local results preserved; review status then retry writeback.'%len(failures))

    return outcomes
