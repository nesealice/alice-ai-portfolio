"""Bounded screenshot media uploads using the standalone app client's own token."""
import json
import struct
import uuid
from urllib.error import HTTPError
from urllib.request import Request
from .feishu import FeishuError

MAX_IMAGE_BYTES=20*1024*1024


class MediaRejected(FeishuError):
    """The service explicitly rejected this upload, so retrying is safe."""
    pass


def image_dimensions(data):
    if data.startswith(b'\x89PNG\r\n\x1a\n') and len(data)>=33 and data[12:16]==b'IHDR':
        width,height=struct.unpack('>II',data[16:24]);mime='image/png'
    elif data.startswith(b'\xff\xd8'):
        pos=2;width=height=0;mime='image/jpeg'
        while pos<len(data):
            if data[pos]!=255:break
            while pos<len(data) and data[pos]==255:pos+=1
            if pos>=len(data):break
            marker=data[pos];pos+=1
            if marker in (0xD9,0xDA):break
            if marker in (0x01,*range(0xD0,0xD8)):continue
            if pos+2>len(data):break
            length=int.from_bytes(data[pos:pos+2],'big')
            if length<2 or pos+length>len(data):break
            if marker in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF) and length>=8:
                height,width=struct.unpack('>HH',data[pos+3:pos+7]);break
            pos+=length
    else:
        raise FeishuError('Screenshot must be a PNG or JPEG image')
    if not width or not height or width>100000 or height>100000:
        raise FeishuError('Invalid screenshot dimensions')
    return width,height,mime


def upload_media(client,base_token,path,max_bytes=MAX_IMAGE_BYTES):
    if client_origin(client) not in ('https://open.feishu.cn','https://open.larksuite.com'):
        raise FeishuError('Only official Feishu/Lark API origins are allowed')
    if path.stat().st_size>max_bytes:
        raise FeishuError('Screenshot exceeds media upload size limit')
    with path.open('rb') as file:data=file.read(max_bytes+1)
    if len(data)>max_bytes:raise FeishuError('Screenshot exceeds media upload size limit')
    width,height,mime=image_dimensions(data)
    if any(c in path.name for c in ('\r','\n','"')):
        raise FeishuError('Invalid screenshot filename')
    boundary='shopee-proof-'+uuid.uuid4().hex
    parts=[]
    for name,value in [('file_name',path.name),('parent_type','bitable_file'),('parent_node',base_token),('size',str(len(data)))]:
        parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+name+'"\r\n\r\n'+value+'\r\n').encode())
    parts.extend([('--'+boundary+'\r\nContent-Disposition: form-data; name="file"; filename="'+path.name+'"\r\nContent-Type: '+mime+'\r\n\r\n').encode(),data,('\r\n--'+boundary+'--\r\n').encode()])
    client.ensure_token()
    request=Request(client.origin+'/open-apis/drive/v1/medias/upload_all',data=b''.join(parts),headers={'Authorization':'Bearer '+client.token,'Content-Type':'multipart/form-data; boundary='+boundary},method='POST')
    try:
        with client.opener.open(request,timeout=120) as response:payload=json.load(response)
    except HTTPError as exc:
        try:
            details=json.loads(exc.read(8192));reason=str(details.get('code',''))+': '+str(details.get('msg',''))[:250]
        except Exception:reason='No structured API error returned'
        error=MediaRejected if 400<=exc.code<500 and exc.code!=408 else FeishuError
        raise error('Feishu media HTTP error %s (%s)'%(exc.code,reason))from None
    if payload.get('code',0)!=0:
        raise MediaRejected('Feishu media API code '+str(payload['code'])+': '+str(payload.get('msg',''))[:250])
    token=payload.get('data',{}).get('file_token')
    if not isinstance(token,str) or not token:raise FeishuError('Media response missing file token; upload outcome unconfirmed')
    return {'file_token':token,'image_width':width,'image_height':height}


def client_origin(client):
    # Invalid local image tests need no configured client or authentication.
    return getattr(client,'origin','https://open.feishu.cn')
