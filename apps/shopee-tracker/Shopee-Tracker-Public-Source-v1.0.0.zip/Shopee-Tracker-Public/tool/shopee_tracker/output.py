"""Local Excel snapshots; standard library only, no AI or cloud credentials."""
import json,os,zipfile,math
from pathlib import Path
from xml.sax.saxutils import escape
from .feishu import build_fields

DIFFS=[('#of live session in last 7 days','Sessions change'),('Average Page Views(PV) in last 7 days','Views change'),('Sales revenue per 1000 PV in last 7 days','GPM change')]
COLUMNS=['SHP Handle Name','Affiliate ID','Date of Tracking','#of live session in last 7 days','Sessions change','Average Page Views(PV) in last 7 days','Views change','Sales revenue per 1000 PV in last 7 days','GPM change','Overall Clicks','Overall Items Sold Raw','Overall Orders Raw','Overall GMV Raw','Overall ROI','Live GPM Raw','Live Likes','Live Comments','Video Count','Video Views','Video GPM','Video GPM Raw','Video Likes','Video Comments','Video GMV Raw','Video Orders Raw','Live GMV Raw','Live Orders Raw','Screenshot','Category tag','TTS Handle name','SHP KOL Link','Channel status','Metric details (raw/status)']

def local_rows(store,payloads=None):
 records=payloads if payloads is not None else{key:json.loads(p)for key,p in store.db.execute('SELECT snapshot_key,payload FROM writebacks')}
 ordered=sorted(records.values(),key=lambda f:(f['Date of Tracking'],f['Affiliate ID']))
 output=[]
 for f in ordered:
  row=dict(f)
  previous=[x for x in ordered if x['Affiliate ID']==f['Affiliate ID']and x.get('Country')==f.get('Country')and x['Date of Tracking']<f['Date of Tracking']]
  latest=max(previous,key=lambda x:x['Date of Tracking'])if previous else{}
  for metric,diff in DIFFS:
   a,b=f.get(metric),latest.get(metric)
   row[diff]=a-b if isinstance(a,(int,float))and isinstance(b,(int,float))else None
  output.append(row)
 return output

def _column(n):
 name=''
 while n:n,r=divmod(n-1,26);name=chr(65+r)+name
 return name

def _text(v):
 return ''.join(c for c in str(v)if c in '\t\n\r'or ord(c)>=32)[:32767]

def write_xlsx(path,rows,columns):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 data=[]
 for i,values in enumerate([columns]+[[r.get(k)for k in columns]for r in rows],1):
  cells=[]
  for j,v in enumerate(values,1):
   if v is None:continue
   ref=_column(j)+str(i)
   if isinstance(v,(int,float))and not isinstance(v,bool)and math.isfinite(v):cells.append(f'<c r="{ref}"><v>{v}</v></c>')
   else:cells.append(f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{escape(_text(v))}</t></is></c>')
  data.append(f'<row r="{i}">'+''.join(cells)+'</row>')
 ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
 worksheet=f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="{ns}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" state="frozen"/></sheetView></sheetViews><cols><col min="1" max="{len(columns)}" width="24" customWidth="1"/></cols><sheetData>'+''.join(data)+f'</sheetData><autoFilter ref="A1:{_column(len(columns))}{len(rows)+1}"/></worksheet>'
 temporary=path.with_suffix('.xlsx.tmp')
 try:
  with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED)as z:
   z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
   z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
   z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Rolling 7 days" sheetId="1" r:id="rId1"/></sheets></workbook>')
   z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
   z.writestr('xl/worksheets/sheet1.xml',worksheet)
  os.chmod(temporary,0o600);os.replace(temporary,path)
 finally:temporary.unlink(missing_ok=True)

def write_local(store,run,config_path,only_targets=None,**ignored):
 from .config import read_config
 from .status import mark
 cfg=read_config(config_path);data=Path(config_path).parent
 path=Path(cfg.get('excel_path')or data/'exports/tracking.xlsx').expanduser()
 if not path.is_absolute():path=data/path
 if path.suffix.lower()!='.xlsx':raise ValueError('Excel 输出路径必须以 .xlsx 结尾')
 record=store.run(run);results=store.results(run);payloads={key:json.loads(p)for key,p in store.db.execute('SELECT snapshot_key,payload FROM writebacks')};updates=[]
 for t in(only_targets if only_targets is not None else record['targets']):
  captures=[r for r in results if r['target']['country']==t.country and r['target']['affiliate_id']==t.affiliate_id]
  if not any(r.get('status')=='ok'and r.get('metrics')for r in captures):continue
  f=build_fields(captures,record['date'],'');f.pop('Creator',None)
  f['Screenshot']='\n'.join(r.get('screenshot')or''for r in captures if r.get('status')=='ok')
  f['Metric details (raw/status)']=json.dumps({r['channel']:{'status':r.get('status'),'metrics':r.get('metrics',{}),'error':r.get('error','')}for r in captures},ensure_ascii=False)
  f['Channel status']='; '.join(r['channel']+': '+r['status']for r in captures)
  for channel,prefix in [('live','Live'),('video','Video')]:
   m=next((r.get('metrics',{})for r in captures if r['channel']==channel and r.get('status')=='ok'),{})
   for label,key in [('GMV(Rp)','GMV Raw'),('Orders','Orders Raw'),('GPM(Rp)','GPM Raw')]:f[prefix+' '+key]=m.get(label,{}).get('raw','')
  payloads[f['Record Key']]=f;updates.append((t,f))
 if not updates:return
 from .config import destination_key
 store.db.execute('CREATE TABLE IF NOT EXISTS output_destinations(snapshot_key TEXT PRIMARY KEY,destination TEXT)')
 for t,f in updates:mark(store,run,t,'writeback','running')
 try:write_xlsx(path,local_rows(store,payloads),COLUMNS)
 except Exception as exc:
  for t,f in updates:mark(store,run,t,'writeback','failed',str(exc))
  raise
 with store.db:
  for t,f in updates:
   store.db.execute('INSERT OR REPLACE INTO writebacks VALUES(?,?,?)',(f['Record Key'],str(path),json.dumps(f,ensure_ascii=False)))
   store.db.execute('INSERT OR REPLACE INTO output_destinations VALUES(?,?)',(f['Record Key'],destination_key(config_path)))
   mark(store,run,t,'writeback','success','',str(path))
 print('Excel saved: '+str(path),flush=True)

def writeback(store,run,config_path,**kwargs):
 from .config import output_mode
 if output_mode(config_path)=='feishu':
  from .feishu import writeback as cloud
  if kwargs.get('preview'):return cloud(store,run,config_path,**kwargs)
  from .config import destination_key
  from .status import mark
  targets=kwargs.get('only_targets')or store.run(run)['targets']
  store.db.execute('CREATE TABLE IF NOT EXISTS output_destinations(snapshot_key TEXT PRIMARY KEY,destination TEXT)');store.db.commit()
  for t in targets:mark(store,run,t,'writeback','running')
  try:outcomes=cloud(store,run,config_path,**kwargs)
  except Exception as exc:
   for t in targets:mark(store,run,t,'writeback','failed',str(exc))
   raise
  for item in outcomes:
   if item.get('state')=='success':
    key='snapshot:'+item['target']+':'+store.run(run)['date']
    with store.db:store.db.execute('INSERT OR REPLACE INTO output_destinations VALUES(?,?)',(key,destination_key(config_path)))
  return outcomes
 if kwargs.get('preview'):
  print('Local Excel output; no cloud writes.');return
 return write_local(store,run,config_path,**kwargs)
