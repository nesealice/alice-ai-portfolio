"""Generate (do not silently install) a macOS per-user launchd schedule."""
import plistlib
import re
from pathlib import Path
import sys


def write_schedule(data,at,config):
    if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',at):
        raise ValueError('Time must be HH:MM (00:00 to 23:59), in the Mac system timezone')
    hour,minute=map(int,at.split(':'))
    source=Path(__file__).resolve().parent.parent
    arguments=[sys.executable,'-m','shopee_tracker','--data-dir',str(data),'daily']
    if getattr(sys,'frozen',False):
        # Parent's packaged UI entry must pass --cli through to main.
        arguments=[sys.executable,'--cli','--data-dir',str(data),'daily']
        source=data
    if config:
        arguments.extend(['--config',str(Path(config).expanduser().resolve())])
    path=data/'com.local.shopeetracker.public.daily.plist'
    payload={'Label':'com.local.shopeetracker.public.daily','ProgramArguments':arguments,
             'WorkingDirectory':str(source),'StartCalendarInterval':{'Hour':hour,'Minute':minute},
             'RunAtLoad':False,'ProcessType':'Interactive',
             'StandardOutPath':str(data/'daily.log'),'StandardErrorPath':str(data/'daily-errors.log'),
             'EnvironmentVariables':{'PLAYWRIGHT_BROWSERS_PATH':str(data/'browsers')}}
    path.write_bytes(plistlib.dumps(payload))
    return str(path)


# The packaged app uses one resident service, rather than launching a second
# Playwright process for every calendar tick. The legacy writer above remains
# available for explicit CLI export only.
import json
import os
import subprocess
from datetime import datetime, timedelta

BACKGROUND_LABEL='com.local.shopeetracker.public.background'
AUTH_MARKERS=('login_required','verification_required','verification_unavailable',
              'existing_chrome_connection_required','manual login/verification',
              'browser has been closed','browser closed','target closed',
              '权限','access denied','feishu_app_id','feishu_app_secret','docs:document.media:upload',
              '尚未登录','登录已失效','需要在浏览器','尚未获准连接','浏览器已关闭','无法完成验证')


def private_json(path,value):
    path=Path(path)
    temporary=path.with_suffix(path.suffix+'.tmp')
    fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as stream:
        os.chmod(temporary,0o600)
        json.dump(value,stream,ensure_ascii=False)
        stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)


class DailySchedule:
    """Call under the service job lock; claim before dispatch survives restart.

    A failed/interrupted attempt remains claimed for that date. User retries
    run the same daily pipeline and its existing durable checkpoints.
    """
    def __init__(self,data):
        self.data=Path(data);self.data.mkdir(parents=True,exist_ok=True)
        os.chmod(self.data,0o700)
        self.path=self.data/'daily-state.json'
        self.state=json.loads(self.path.read_text()) if self.path.exists() else {}

    def record_collection(self,now=None):
        day=(now or datetime.now()).date().isoformat()
        self.state['last_claimed_date']=max(day,self.state.get('last_claimed_date',''))
        private_json(self.path,self.state)

    def claim(self,now=None,busy=False):
        now=now or datetime.now()
        due=now.replace(hour=10,minute=0,second=0,microsecond=0)
        if busy or now<due or now.date().isoformat()<=self.state.get('last_claimed_date',''):
            return False
        self.record_collection(now)
        return True

    def result(self,error):
        error=str(error or '')
        self.state.update(needs_auth=any(x in error.lower() for x in AUTH_MARKERS),last_error=error[-2000:])
        private_json(self.path,self.state)

    def snapshot(self,now=None):
        now=now or datetime.now()
        next_run=now.replace(hour=10,minute=0,second=0,microsecond=0)
        if now.date().isoformat()<=self.state.get('last_claimed_date',''):
            last=datetime.fromisoformat(self.state['last_claimed_date'])
            next_run=(last+timedelta(days=1)).replace(hour=10,minute=0)
        return dict(self.state,enabled=True,next_run=next_run.isoformat(),
                    needs_auth=self.state.get('needs_auth',False),
                    catch_up_pending=now>=next_run)


def write_background_agent(data,executable,agents):
    data=Path(data).expanduser().resolve();data.mkdir(parents=True,exist_ok=True);os.chmod(data,0o700)
    agents=Path(agents).expanduser();agents.mkdir(parents=True,exist_ok=True)
    executable=Path(executable).expanduser().resolve()
    payload={'Label':BACKGROUND_LABEL,'ProgramArguments':[str(executable),'--background'],
             'WorkingDirectory':str(data),'RunAtLoad':True,'KeepAlive':True,
             'ThrottleInterval':15,'ProcessType':'Interactive',
             'StandardOutPath':str(data/'background.log'),
             'StandardErrorPath':str(data/'background-errors.log'),
             'EnvironmentVariables':{'SHOPEE_TRACKER_DATA':str(data)}}
    path=agents/(BACKGROUND_LABEL+'.plist')
    path.write_bytes(plistlib.dumps(payload));os.chmod(path,0o600)
    for name in ('background.log','background-errors.log'):
        log=data/name;log.touch(exist_ok=True);os.chmod(log,0o600)
    return str(path)


def install_background_agent(data,executable,agents=None,runner=None):
    """Install for a packaged first launch or an explicit installer request."""
    runner=runner or subprocess.run
    agents=Path(agents or Path.home()/'Library'/'LaunchAgents')
    path=agents/(BACKGROUND_LABEL+'.plist')
    before=path.read_bytes() if path.exists() else None
    path=Path(write_background_agent(data,executable,agents))
    domain='gui/'+str(os.getuid());service=domain+'/'+BACKGROUND_LABEL
    loaded=runner(['/bin/launchctl','print',service],capture_output=True).returncode==0
    if loaded and before!=path.read_bytes():
        runner(['/bin/launchctl','bootout',service],check=True,capture_output=True)
        loaded=False
    if not loaded:
        runner(['/bin/launchctl','bootstrap',domain,str(path)],check=True,capture_output=True)
    return str(path)



def background_agent_installed(data,executable,agents=None):
    agents=Path(agents or Path.home()/'Library'/'LaunchAgents')
    try:
        payload=plistlib.loads((agents/(BACKGROUND_LABEL+'.plist')).read_bytes())
        return (isinstance(payload,dict) and payload.get('ProgramArguments')==[str(Path(executable).expanduser().resolve()),'--background']
                and payload.get('EnvironmentVariables',{}).get('SHOPEE_TRACKER_DATA')==str(Path(data).expanduser().resolve())
                and payload.get('RunAtLoad') is True and payload.get('KeepAlive') is True)
    except (OSError,ValueError,plistlib.InvalidFileException):return False
