"""Persistent, human-readable status. Never infers cloud success from collection."""
import json,sqlite3
from pathlib import Path
from urllib.parse import quote

CHANNEL_NAMES={'sales':'销售总览','live':'直播','video':'短视频'}

def friendly_error(error):
 text=str(error or '')
 rules=[(('91403',),'飞书应用无权访问此表，请在目标多维表中添加应用并授予可编辑权限；本地数据已保存'),
        (('channel_not_offered',),'该达人官方页面未提供此渠道入口，指标留空；不代表数值为 0'),
        (('docs:document.media:upload',),'飞书截图上传权限未生效，请管理员开通媒体上传权限；本机截图已保留'),
        (('base:record:read','base:record:create','base:record:update'),'飞书开放平台的应用记录权限未生效，请管理员开通对应权限；本地数据已保存'),
        (('existing_chrome_connection_required',),'尚未获准连接你的现有 Chrome，请在 Chrome 中允许本机连接'),(('verification_unavailable',"Verification can't be completed",'Please Try Again Later'),'Shopee 暂时无法完成验证，请稍后在浏览器中重试'),
        (('login_required',),'尚未登录或登录已失效，请先更新登录'),
        (('verification_required',),'需要在浏览器中完成 Shopee 验证'),
        (('no_permission',),'当前账号没有查看该页面的权限'),
        (('loading_timeout','Cannot identify single closed period dropdown','DOM did not stabilize'),'达人数据页面尚未加载完成，暂未提取到数据'),
        (('ERR_ABORTED',),'页面跳转被中断，尚未进入达人数据页'),
        (('browser has been closed','Browser closed','Target closed'),'浏览器已关闭，采集未完成'),
        (('FEISHU_APP_ID','FEISHU_APP_SECRET','base-config.json'),'飞书应用尚未配置完整；数据已保存在本机'),
        (('Feishu HTTP error','permission','scope','API code'),'飞书授权、访问权限或接口响应异常；数据已保存在本机'),
        (('conflict','differs','overwrite','Duplicate'),'飞书中存在同日冲突记录，已保留原记录，需核对后重试'),
        (('Unverified seven-day','period','Last 7 Days'),'未能确认最近 7 天统计范围，未写入该数据'),
        (('identity','username','Mixed target'),'未能确认达人身份，未写入该数据'),
        (('timeout','timed out','Timeout'),'请求超时，请稍后重试；本地结果仍保留')]
 for needles,message in rules:
  if any(n.lower() in text.lower() for n in needles):return message
 return '页面结构或数据读取异常，请重试；详情可展开查看' if text else ''

def mark(store,run,target,phase,state,detail='',record_id=''):
 with store.db:
  store.db.execute('CREATE TABLE IF NOT EXISTS progress(run TEXT,country TEXT,affiliate TEXT,phase TEXT,state TEXT,detail TEXT,record_id TEXT,PRIMARY KEY(run,country,affiliate,phase))')
  store.db.execute('INSERT OR REPLACE INTO progress VALUES(?,?,?,?,?,?,?)',(run,target.country,target.affiliate_id,phase,state,str(detail),record_id))

def proof_complete(results,state,details):
 good=[r for r in results if r.get('status')=='ok'and r.get('metrics')]
 expected=[r.get('screenshot')for r in good]
 return bool(good and all(expected) and state=='uploaded_verified'and set(expected)==set(details.get('paths',[])))


def read_dashboard(data):
 empty={'date':None,'run_id':None,'creators':[],'summary':{'total':0,'extracted':0,'partial':0,'failed':0,'written':0,'write_failed':0,'proof_uploaded':0,'proof_failed':0}}
 path=Path(data)/'state.sqlite'
 if not path.exists():return empty
 # Normal read-only mode includes active WAL commits; immutable would miss them.
 db=sqlite3.connect('file:'+quote(str(path))+'?mode=ro',uri=True,timeout=1)
 try:
  run=db.execute('SELECT id,date,targets FROM runs ORDER BY rowid DESC LIMIT 1').fetchone()
  if not run:return empty
  rid,date,targets=run;targets=json.loads(targets)
  rows=[json.loads(x[0])for x in db.execute('SELECT payload FROM snapshots WHERE run=?',(rid,))]
  tables={x[0]for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
  progress={(country,aid,phase):(state,detail,rec)for country,aid,phase,state,detail,rec in db.execute('SELECT country,affiliate,phase,state,detail,record_id FROM progress WHERE run=?',(rid,))}if'progress'in tables else {}
  records={key:json.loads(payload)for key,payload in db.execute('SELECT snapshot_key,payload FROM writebacks')}
  proofs={key:(state,json.loads(details))for key,state,details in db.execute('SELECT snapshot_key,state,details FROM attachment_uploads')}if'attachment_uploads'in tables else {}
  from .config import destination_key
  destination=destination_key(Path(data)/'base-config.json')
  destinations=dict(db.execute('SELECT snapshot_key,destination FROM output_destinations'))if'output_destinations'in tables else None
  result=dict(empty,date=date,run_id=rid,creators=[],summary=dict(empty['summary'],total=len(targets)))
  for t in targets:
   channels={r['channel']:r for r in rows if r['target']['country']==t['country']and r['target']['affiliate_id']==t['affiliate_id']}
   ok=[c for c,r in channels.items()if r.get('status')=='ok'and r.get('metrics')]
   extract='提取成功'if len(ok)==3 else'部分提取成功'if ok else'提取失败'if channels else'待采集'
   p=progress.get((t['country'],t['affiliate_id'],'extraction'))
   if p and p[0]=='running':extract='正在提取'
   errors=[r.get('error','')for r in channels.values()if r.get('status')!='ok']
   reason=next((friendly_error(e)for e in errors if e),'')
   sync=progress.get((t['country'],t['affiliate_id'],'writeback'))
   key='snapshot:%s:%s:%s'%(t['country'],t['affiliate_id'],date)
   written=records.get(key)
   current_destination=destinations is None or destinations.get(key)==destination
   if not current_destination and sync and sync[0]=='success':sync=('pending','',None)
   # An older successful subset must not mask new results waiting for sync.
   same=bool(current_destination and written and written.get('Raw Metrics JSON')==json.dumps([channels[c]for c in sorted(channels)],ensure_ascii=False))
   if sync:
    if sync[0]=='success'and not same:sync=('pending','',sync[2])
    label={'running':'正在写入','success':'写入成功','failed':'写入失败','blocked':'无需写入','pending':'等待自动写入'}.get(sync[0],'等待自动写入')
    if sync[1] and sync[0]=='failed':reason=friendly_error(sync[1])
    record_id=sync[2]
   else:
    label='写入成功'if same else'等待自动写入'if ok else'无需写入'if channels else'等待提取'
    record_id=''
   proof=sum(bool(channels[c].get('screenshot'))for c in ok)
   proof_state,proof_details=proofs.get(key,('pending',{}))
   verified=current_destination and proof_complete(channels.values(),proof_state,proof_details)
   cloud='飞书附件：上传成功'if verified else'飞书附件：上传待核验'if proof_state in ('upload_unconfirmed','append_unconfirmed','uploaded_verified')else'飞书附件：部分上传成功'if proof_state=='partial_uploaded_verified'else'飞书附件：上传失败'if proof_state not in ('pending','local_only')else'飞书附件：未上传'
   if verified:result['summary']['proof_uploaded']+=1
   elif ok:
    result['summary']['proof_failed']+=1
    if proof_details.get('notes') and not reason:reason=friendly_error(proof_details['notes'])
   details={CHANNEL_NAMES[c]:{'status':'提取成功'if c in ok else'平台未提供'if channels.get(c,{}).get('status')=='channel_not_offered'else'提取失败'if c in channels else'待采集','reason':friendly_error(channels.get(c,{}).get('error',''))}for c in CHANNEL_NAMES}
   result['creators'].append(dict(affiliate_id=t['affiliate_id'],name=t['shopee_handle'],extraction=extract,writeback=label,reason=reason,channels=details,proof='已保存 %d 张数据截图'%proof if proof else'暂无数据截图',cloud_proof=cloud,record_id=record_id))
   if extract=='提取成功':result['summary']['extracted']+=1
   elif extract=='部分提取成功':result['summary']['partial']+=1
   elif extract=='提取失败':result['summary']['failed']+=1
   if label=='写入成功':result['summary']['written']+=1
   elif label=='写入失败':result['summary']['write_failed']+=1
  return result
 finally:db.close()
