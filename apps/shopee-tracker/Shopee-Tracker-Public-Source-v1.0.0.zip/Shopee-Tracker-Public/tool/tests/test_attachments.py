import tempfile
import subprocess
import unittest
from pathlib import Path
from unittest.mock import patch
from shopee_tracker.core import Store
from shopee_tracker.attachments import upload_proofs

class Attachments(unittest.TestCase):
    def test_cli_commit_timeout_is_reconciled_without_reupload(self):
        class Client:
            files=[]
            def records(self): return [{'record_id':'rec1','fields':{'Screenshot':self.files}}]
        client=Client()
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'1-20261023-live.png';p.write_bytes(b'fixture')
            db=Store(Path(tmp)/'db.sqlite')
            config={'base_token':'base','snapshot_table_id':'tbl','screenshot_upload_mode':'lark-cli-user'}
            def committed(args,**kwargs):
                client.files=[{'name':p.name,'file_token':'newtoken'}]
                raise subprocess.TimeoutExpired(args,1)
            with patch('shopee_tracker.attachments.shutil.which',return_value='/tmp/lark-cli'),patch('shopee_tracker.attachments.subprocess.run',side_effect=committed) as run:
                result=upload_proofs(config,db,'key','rec1',[str(p)],client)
                self.assertEqual(result['state'],'uploaded_verified')
                again=upload_proofs(config,db,'key','rec1',[str(p)],client)
                self.assertEqual(again['state'],'uploaded_verified')
                self.assertEqual(run.call_count,1)
            db.close()

    def test_ambiguous_timeout_never_blindly_repeats(self):
        class Client:
            def records(self): return [{'record_id':'rec1','fields':{'Screenshot':[]}}]
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'live.png';p.write_bytes(b'fixture')
            db=Store(Path(tmp)/'db.sqlite')
            config={'base_token':'base','snapshot_table_id':'tbl','screenshot_upload_mode':'lark-cli-user'}
            with patch('shopee_tracker.attachments.shutil.which',return_value='/tmp/lark-cli'),patch('shopee_tracker.attachments.subprocess.run',side_effect=subprocess.TimeoutExpired('cli',1)) as run:
                first=upload_proofs(config,db,'key','rec1',[str(p)],Client())
                second=upload_proofs(config,db,'key','rec1',[str(p)],Client())
                self.assertEqual(first['state'],'upload_unconfirmed')
                self.assertEqual(second['state'],'upload_unconfirmed')
                self.assertEqual(run.call_count,1)
            db.close()
    def test_resume_uploads_only_new_proofs_and_preserves_prior_confirmed_files(self):
        class Client:
            files=[]
            def records(self):return [{'record_id':'rec1','fields':{'Screenshot':self.files}}]
        client=Client()
        with tempfile.TemporaryDirectory() as tmp:
            a=Path(tmp)/'live.png';b=Path(tmp)/'video.png';a.write_bytes(b'fixture');b.write_bytes(b'fixture')
            db=Store(Path(tmp)/'db.sqlite');config={'base_token':'base','snapshot_table_id':'tbl','screenshot_upload_mode':'lark-cli-user'}
            def committed(args,**kwargs):
                for i,v in enumerate(args):
                    if v=='--file':
                        file=Path(args[i+1])
                        if file.is_absolute()or not(Path(kwargs.get('cwd','/'))/file).is_file():raise OSError('CLI requires a valid relative file path')
                        client.files.append({'name':file.name})
                return subprocess.CompletedProcess(args,0,'{}','')
            with patch('shopee_tracker.attachments.shutil.which',return_value='/tmp/lark-cli'),patch('shopee_tracker.attachments.subprocess.run',side_effect=committed)as run:
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(a)],client)['state'],'uploaded_verified')
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(a),str(b)],client)['state'],'uploaded_verified')
                self.assertEqual([x['name']for x in client.files],['live.png','video.png'])
                self.assertNotIn(str(a),run.call_args.args[0])
            db.close()

class AppAttachments(unittest.TestCase):
    def setup_case(self,tmp):
        from test_media import png
        path=Path(tmp)/'current-live.png';path.write_bytes(png())
        store=Store(Path(tmp)/'app.sqlite')
        class Client:
            files=[]
            requests=[]
            def records(self):return [{'record_id':'rec1','fields':{'Screenshot':self.files}}]
            def request(self,method,path,body):
                self.requests.append((method,path,body))
                self.files=[{'name':'current-live.png','file_token':'file1'}]
                return {}
        return path,store,Client(),{'base_token':'base','snapshot_table_id':'tbl'}

    def test_default_app_mode_uploads_and_verifies_attachment(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,db,client,config=self.setup_case(tmp)
            with patch('shopee_tracker.attachments.upload_media',return_value={'file_token':'file1','image_width':12,'image_height':7})as upload:
                result=upload_proofs(config,db,'key','rec1',[str(p),None],client)
                self.assertEqual(result['state'],'partial_uploaded_verified')
                self.assertEqual(client.requests[0],('POST','/open-apis/base/v3/bases/base/tables/tbl/append_attachments',{'attachments':{'rec1':{'Screenshot':[{'file_token':'file1','image_width':12,'image_height':7}]}}}))
                upload_proofs(config,db,'key','rec1',[str(p)],client)
                self.assertEqual(upload.call_count,1)
            db.close()

    def test_append_timeout_commit_reconciles_without_reupload(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,db,client,config=self.setup_case(tmp)
            def append(*args):
                client.files=[{'name':p.name,'file_token':'file1'}]
                raise TimeoutError('committed')
            client.request=append
            with patch('shopee_tracker.attachments.upload_media',return_value={'file_token':'file1','image_width':12,'image_height':7})as upload:
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'uploaded_verified')
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'uploaded_verified')
                self.assertEqual(upload.call_count,1)
            db.close()

    def test_uncertain_append_is_durable_and_never_blindly_repeated(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,db,client,config=self.setup_case(tmp)
            client.request=lambda *args:(_ for _ in ()).throw(TimeoutError('unknown'))
            with patch('shopee_tracker.attachments.upload_media',return_value={'file_token':'file1','image_width':12,'image_height':7})as upload:
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'append_unconfirmed')
                db.close();db=Store(Path(tmp)/'app.sqlite')
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'append_unconfirmed')
                self.assertEqual(upload.call_count,1)
                saved=db.db.execute('SELECT details FROM attachment_files').fetchone()[0]
                self.assertIn('file1',saved)
            db.close()

    def test_readback_failure_performs_no_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,db,client,config=self.setup_case(tmp)
            client.records=lambda:(_ for _ in ()).throw(TimeoutError())
            with patch('shopee_tracker.attachments.upload_media')as upload:
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'readback_failed')
                upload.assert_not_called()
            db.close()

    def test_rejected_append_reuses_uploaded_token_after_permission_fixed(self):
        from shopee_tracker.feishu import FeishuError
        with tempfile.TemporaryDirectory() as tmp:
            p,db,client,config=self.setup_case(tmp)
            original=client.request
            client.request=lambda *args:(_ for _ in ()).throw(FeishuError('Feishu API code 99991672: permission denied'))
            with patch('shopee_tracker.attachments.upload_media',return_value={'file_token':'file1','image_width':12,'image_height':7})as upload:
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'append_rejected')
                client.request=original
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'uploaded_verified')
                self.assertEqual(upload.call_count,1)
            db.close()

    def test_rejected_media_can_retry_after_scope_granted(self):
        from shopee_tracker.media import MediaRejected
        with tempfile.TemporaryDirectory() as tmp:
            p,db,client,config=self.setup_case(tmp)
            with patch('shopee_tracker.attachments.upload_media',side_effect=[MediaRejected('permission denied'),{'file_token':'file1','image_width':12,'image_height':7}])as upload:
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'upload_rejected')
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'uploaded_verified')
                self.assertEqual(upload.call_count,2)
            db.close()

    def test_uncertain_media_is_durable_without_claiming_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,db,client,config=self.setup_case(tmp)
            with patch('shopee_tracker.attachments.upload_media',side_effect=TimeoutError('unknown media outcome'))as upload:
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'upload_unconfirmed')
                db.close();db=Store(Path(tmp)/'app.sqlite')
                self.assertEqual(upload_proofs(config,db,'key','rec1',[str(p)],client)['state'],'upload_unconfirmed')
                self.assertEqual(upload.call_count,1)
                self.assertFalse(client.requests)
            db.close()
