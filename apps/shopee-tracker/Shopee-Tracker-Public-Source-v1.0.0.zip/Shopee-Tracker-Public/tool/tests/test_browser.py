"""Offline DOM contract tests; fixtures deliberately do not claim live equivalence."""
import unittest
from shopee_tracker.browser import selected_evidence, detect_blocker, scope_text
from shopee_tracker.core import UnsupportedDOM

class BrowserContract(unittest.TestCase):
    def test_period_text_without_selected_evidence_is_rejected(self):
        self.assertFalse(selected_evidence({'text':'Last 7 Days','class':''}))
        self.assertTrue(selected_evidence({'text':'Last 7 Days','aria-selected':'true'}))
        self.assertTrue(selected_evidence({'text':'Last 7 Days','class':'tab selected'}))
        self.assertFalse(selected_evidence({'text':'Last 7 Days','class':'not-selected'}))

    def test_mixed_live_video_container_cannot_be_parsed_as_live(self):
        with self.assertRaises(UnsupportedDOM):
            scope_text('Views\n10\nShopee Live\nShopee Video\nViews\n20', 'live')
        self.assertEqual(scope_text('Views\n10\nLikes\n1','live'),'Views\n10\nLikes\n1')

    def test_login_and_captcha_are_explicit_states(self):
        self.assertEqual(detect_blocker('https://seller.shopee.co.id/account/signin',''), 'login_required')
        self.assertEqual(detect_blocker('https://seller.shopee.co.id/portal','Verify you are human'), 'verification_required')
        self.assertEqual(detect_blocker('https://seller.shopee.co.id/portal','You do not have permission'), 'no_permission')
        self.assertIsNone(detect_blocker('https://seller.shopee.co.id/portal','Sales Metrics'))

class ExistingChrome(unittest.TestCase):
    def test_attach_to_current_chrome_and_close_only_owned_tab(self):
        from shopee_tracker.browser import launch
        from unittest.mock import Mock
        from pathlib import Path
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            pw=Mock();browser=pw.chromium.connect_over_cdp.return_value
            context=Mock();page=Mock();page.is_closed.return_value=False
            browser.contexts=[context];context.new_page.return_value=page
            session=launch(pw,Path(tmp),'ID')
            self.assertEqual(pw.chromium.connect_over_cdp.call_args.args,('chrome',))
            self.assertTrue(pw.chromium.connect_over_cdp.call_args.kwargs['no_defaults'])
            pw.chromium.launch_persistent_context.assert_not_called()
            self.assertFalse((Path(tmp)/'profiles').exists())
            self.assertEqual(session.pages,[page]);session.close()
            page.close.assert_called_once();context.close.assert_not_called()
            browser.close.assert_called_once()
    def test_missing_browser_permission_never_silently_launches_another_profile(self):
        from shopee_tracker.browser import launch
        from unittest.mock import Mock
        from pathlib import Path
        pw=Mock();pw.chromium.connect_over_cdp.side_effect=RuntimeError('not enabled')
        with self.assertRaisesRegex(RuntimeError,'existing_chrome_connection_required'):
            launch(pw,Path('/tmp/unused'),'ID')
        pw.chromium.launch_persistent_context.assert_not_called()

class ActualShopeeControls(unittest.TestCase):
    def test_hashed_selected_class_is_distinct_from_not_selected(self):
        from shopee_tracker.browser import selected_evidence
        self.assertTrue(selected_evidence({'class':'src-components-KOLMarketplace-KeyMetrics---selected-platform--h8AWj'}))
        self.assertFalse(selected_evidence({'class':'src-components-KOLMarketplace-KeyMetrics---not-selected-platform--1wBH0'}))

class PersistentConnection(unittest.TestCase):
    def test_app_actions_reuse_connection_and_close_only_job_tabs(self):
        import os,tempfile
        from pathlib import Path
        from unittest.mock import Mock,patch
        from shopee_tracker.browser import launch
        pw=Mock();browser=pw.chromium.connect_over_cdp.return_value;browser.is_connected.return_value=True
        context=Mock();browser.contexts=[context];context.new_page.side_effect=[Mock(),Mock()]
        with tempfile.TemporaryDirectory()as tmp,patch.dict(os.environ,{'SHOPEE_TRACKER_KEEP_BROWSER':'1'}):
            one=launch(pw,Path(tmp),'ID');one.close();two=launch(pw,Path(tmp),'ID');two.close()
        self.assertEqual(pw.chromium.connect_over_cdp.call_count,1)
        browser.close.assert_not_called();context.close.assert_not_called()
