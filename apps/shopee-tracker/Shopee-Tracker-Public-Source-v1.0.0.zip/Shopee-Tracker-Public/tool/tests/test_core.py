import csv
import json
import tempfile
import unittest
from pathlib import Path

from shopee_tracker.core import (parse_number, load_targets, extract_metrics,
                                 verify_identity, Store, UnsupportedDOM, Target)

URL = 'https://seller.shopee.co.id/portal/web-seller-affiliate/kol_marketplace/detail?affiliate_id=123'

class Numbers(unittest.TestCase):
    def test_id_ranges_and_currency_are_not_exact_values(self):
        n = parse_number('Rp200JT–1M', 'ID', 'GMV(Rp)')
        self.assertEqual(n['lower'], '200000000')
        self.assertEqual(n['upper'], '1000000000')
        self.assertIsNone(n['value'])
        self.assertEqual(n['currency'], 'IDR')
        self.assertEqual(parse_number('>50RB', 'ID')['operator'], '>')
        self.assertEqual(parse_number('24.293', 'ID')['value'], '24293')
        self.assertEqual(parse_number('6,12', 'ID')['value'], '6.12')

    def test_unknown_is_never_zero_and_th_units_are_independent(self):
        for text in ('', '—', 'No Data', 'Tidak Ada Data'):
            self.assertIsNone(parse_number(text, 'ID')['value'])
        self.assertEqual(parse_number('0', 'TH')['value'], '0')
        self.assertEqual(parse_number('฿1,234.50', 'TH')['value'], '1234.50')
        self.assertEqual(parse_number('2JT', 'TH')['status'], 'unknown_unit')
        self.assertEqual(parse_number('1M', 'TH')['status'], 'unknown_unit')

class Inputs(unittest.TestCase):
    def test_reject_wrong_domain_and_merge_duplicate_source_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'targets.csv'
            with p.open('w', newline='') as f:
                w=csv.DictWriter(f, fieldnames=['country','affiliate_id','shopee_handle','url','source_rows'])
                w.writeheader()
                for row in ('2','17'):
                    w.writerow(dict(country='ID',affiliate_id='123',shopee_handle='alice',url=URL,source_rows=row))
            targets=load_targets(p)
            self.assertEqual(len(targets),1)
            self.assertEqual(targets[0].source_rows,['2','17'])
            p.write_text('country,affiliate_id,shopee_handle,url\nID,123,alice,https://evil.test/detail?affiliate_id=123')
            with self.assertRaises(ValueError): load_targets(p)

    def test_identity_requires_exact_username_and_id(self):
        t=Target('ID','123','alice',URL,[])
        verify_identity(t,URL,'alice\nSales Metrics')
        with self.assertRaises(UnsupportedDOM): verify_identity(t,URL,'malice\nSales Metrics')
        with self.assertRaises(UnsupportedDOM): verify_identity(t,URL.replace('123','124'),'alice')

class Parsing(unittest.TestCase):
    def test_live_fixture_preserves_raw_values_and_missing_fields(self):
        fixture=json.loads((Path(__file__).parent/'fixtures'/'id-live.json').read_text())
        metrics=extract_metrics(fixture['text'],'ID','live')
        self.assertEqual(metrics['Views']['raw'],'24.293')
        self.assertEqual(metrics['Views']['value'],'24293')
        self.assertEqual(metrics['GPM(Rp)']['value'],'16954')
        self.assertEqual(metrics['Comments']['status'],'not_displayed')
        self.assertNotIn('GMV(Rp)',metrics)

    def test_unsupported_and_ambiguous_dom_fails_instead_of_empty_success(self):
        with self.assertRaises(UnsupportedDOM): extract_metrics('unexpected markup','ID','live')
        with self.assertRaises(UnsupportedDOM): extract_metrics('Views\n10\nViews\n20','ID','live')

class Persistence(unittest.TestCase):
    def test_officially_unoffered_channel_is_terminal_only_for_that_snapshot(self):
        with tempfile.TemporaryDirectory()as tmp:
            db=Store(Path(tmp)/'db.sqlite');t=Target('ID','123','alice',URL,[]);run=db.new_run([t],'2026-10-23')
            db.save(run,t,'live',{'status':'channel_not_offered','error':'channel_not_offered: Shopee Live'})
            self.assertNotIn('live',db.pending(run,t))
            next_run=db.new_run([t],'2026-10-24');self.assertIn('live',db.pending(next_run,t));db.close()
    def test_resume_keeps_successful_channels_and_date_boundaries(self):
        with tempfile.TemporaryDirectory() as tmp:
            db=Store(Path(tmp)/'state.sqlite')
            t=Target('ID','123','alice',URL,[])
            run=db.new_run([t], '2026-10-23')
            db.save(run,t,'sales',{'status':'ok','metrics':{'GMV(Rp)':parse_number('0','ID','GMV(Rp)')}})
            self.assertEqual(db.pending(run,t),['live','video'])
            db.save(run,t,'live',{'status':'unsupported_dom','error':'page changed'})
            self.assertEqual(db.pending(run,t),['live','video'])
            other=db.new_run([t], '2026-10-24')
            self.assertEqual(db.pending(other,t),['sales','live','video'])
            self.assertEqual(next(r for r in db.results(run) if r['channel']=='sales')['metrics']['GMV(Rp)']['value'],'0')
            db.close()

if __name__=='__main__': unittest.main()
