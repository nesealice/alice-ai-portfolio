"""Rendered synthetic DOM: proves adapter mechanics, not actual Shopee compatibility.
Run only with RUN_DOM_TESTS=1 and an installed Playwright Chromium.
"""
import os
from pathlib import Path
import tempfile
import unittest
from shopee_tracker.browser import VisibleAdapter
from shopee_tracker.core import Target, UnsupportedDOM

@unittest.skipUnless(os.environ.get('RUN_DOM_TESTS')=='1','opt-in rendered fixture test; Playwright Chromium required')
class RenderedDOM(unittest.TestCase):
    def test_video_only_creator_never_fabricates_live_zero(self):
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            browser=pw.chromium.launch(headless=True,channel='chrome')
            try:
                page=browser.new_page();page.set_content('<h2>Shopee Internal Channel</h2><button>Shopee Video</button><div>Video Post</div><div>46</div>')
                with self.assertRaisesRegex(UnsupportedDOM,'channel_not_offered: Shopee Live'):
                    VisibleAdapter(page).select_channel('live')
            finally:browser.close()

    def test_actual_selected_value_is_verified_when_hover_options_remain_open(self):
        from playwright.sync_api import sync_playwright
        html='''<div class="eds-react-select__inner" onclick="document.querySelector('#menu').hidden=false">Last 30 Days</div>
        <div id="menu" hidden><div class="eds-react-select-option" onclick="document.querySelector('.eds-react-select__inner').innerText='Last 7 Days';document.querySelector('#comparison').innerText='vs Previous 7 Days'">Last 7 Days</div><div>Last 30 Days</div></div>
        <style>@keyframes drift{from{transform:translateX(0)}to{transform:translateX(30px)}}h2{animation:drift .2s infinite alternate}</style>
        <h2>Sales Metrics</h2><div>Clicks</div><div>1RB</div><div id="comparison">vs Previous 30 Days</div>'''
        with sync_playwright() as pw:
            browser=pw.chromium.launch(headless=True,channel='chrome')
            try:
                page=browser.new_page();page.set_default_timeout(800);page.set_content(html)
                VisibleAdapter(page).set_period()
                self.assertTrue(page.locator('#menu').is_visible())
                self.assertEqual(VisibleAdapter(page).verify_period()['selected'],'Last 7 Days')
            finally:browser.close()

    def test_header_only_loading_page_is_never_ready(self):
        from playwright.sync_api import sync_playwright
        import time
        with sync_playwright() as pw:
            browser=pw.chromium.launch(headless=True,channel='chrome')
            try:
                page=browser.new_page()
                page.set_content('<header>Affiliate Details demo_seller</header><main><h2>Sales Metrics</h2><button>Last 7 Days</button><div>Loading</div></main>')
                started=time.monotonic()
                with self.assertRaisesRegex(UnsupportedDOM,'loading_timeout'):
                    VisibleAdapter(page).wait_ready(timeout=2)
                self.assertGreaterEqual(time.monotonic()-started,1.5)
            finally:browser.close()

    def test_reload_seven_days_and_three_independent_channels(self):
        from playwright.sync_api import sync_playwright
        html=(Path(__file__).parent/'fixtures'/'detail.html').read_text()
        html+='<style>@keyframes shift{from{transform:translateX(0)}to{transform:translateX(30px)}}.tab{animation:shift .2s infinite alternate}</style>'
        target=Target('ID','123','alice','https://seller.shopee.co.id/portal/web-seller-affiliate/kol_marketplace/detail?affiliate_id=123',[])
        with sync_playwright() as pw, tempfile.TemporaryDirectory() as temp:
            browser=pw.chromium.launch(headless=True,channel='chrome')
            try:
                page=browser.new_page()
                page.set_default_timeout(1000)
                page.route('**/*',lambda route:route.fulfill(status=200,body=html,content_type='text/html'))
                page.goto(target.url)
                adapter=VisibleAdapter(page)
                adapter.set_period()
                sales=adapter.read(target,'sales',Path(temp))
                live=adapter.read(target,'live',Path(temp))
                video=adapter.read(target,'video',Path(temp))
                self.assertEqual(sales['metrics']['GMV(Rp)']['lower'],'10000000000')
                self.assertEqual(live['metrics']['Views']['value'],'24293')
                self.assertEqual(video['metrics']['Views']['value'],'12')
                self.assertEqual(live['period']['selected'],'Last 7 Days')
                self.assertTrue(Path(live['screenshot']).exists())
                from unittest.mock import patch
                with patch.object(page,'screenshot',side_effect=RuntimeError('fixture screenshot failure')):
                    proof_failed=adapter.read(target,'live',Path(temp))
                self.assertEqual(proof_failed['status'],'ok')
                self.assertEqual(proof_failed['metrics']['Views']['value'],'24293')
                self.assertIsNone(proof_failed['screenshot'])
                self.assertEqual(proof_failed['screenshot_status'],'failed')
                adapter.select_channel('live')
                page.evaluate("""() => {
                  document.querySelectorAll('#channel .metric').forEach(x=>{if(x.innerText.startsWith('Views'))x.remove()});
                  let outside=document.createElement('section');
                  outside.innerHTML='<div class="metric"><div>Views</div><div>999</div></div>';
                  document.body.append(outside);
                  let other=document.createElement('section');
                  other.innerHTML='<div class="metric"><div>Videos Published</div><div>3</div></div><div class="metric"><div>Views</div><div>888</div></div>';
                  document.getElementById('internal').append(other);
                }""")
                # read() clicks Live again, so freeze render to preserve this
                # intentionally missing live card and unrelated visible metric.
                page.evaluate("document.getElementById('liveTab').onclick=()=>{}")
                missing=adapter.read(target,'live',Path(temp))
                self.assertEqual(missing['metrics']['Views']['status'],'not_displayed')
                page.evaluate("document.querySelectorAll('.tab').forEach(x=>x.className='tab')")
                page.evaluate("document.querySelectorAll('.tab').forEach(x=>x.onclick=()=>{})")
                with self.assertRaises(UnsupportedDOM): adapter.select_channel('live')
            finally:
                browser.close()
