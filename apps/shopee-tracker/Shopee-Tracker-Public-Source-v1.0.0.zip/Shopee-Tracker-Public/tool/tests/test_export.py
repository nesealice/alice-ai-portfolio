import csv
import json
import tempfile
import unittest
from pathlib import Path
from shopee_tracker.export import export_results

class Export(unittest.TestCase):
    def test_csv_retains_zero_unknown_raw_ranges_and_failures(self):
        rows=[{'channel':'live','status':'ok','target':{'country':'ID','affiliate_id':'1','shopee_handle':'=bad'},
            'metrics':{'Views':{'raw':'0','value':'0','status':'numeric'},'GPM(Rp)':{'raw':'>10M','value':None,'lower':'10000000000','status':'bound'}}},
            {'channel':'video','status':'no_permission','target':{'country':'ID','affiliate_id':'1','shopee_handle':'=bad'},'error':'no permission'}]
        with tempfile.TemporaryDirectory() as tmp:
            export_results(rows,Path(tmp)/'data')
            with (Path(tmp)/'data.csv').open(encoding='utf-8-sig') as f: data=list(csv.DictReader(f))
            self.assertEqual(data[0]['value'],'0')
            self.assertEqual(data[1]['value'],'')
            self.assertEqual(data[1]['lower'],'10000000000')
            self.assertEqual(data[2]['channel_status'],'no_permission')
            self.assertTrue(data[0]['shopee_handle'].startswith("'="))
            self.assertEqual(json.loads((Path(tmp)/'data.json').read_text())['results'],rows)
