import tempfile
import unittest
from pathlib import Path
from shopee_tracker.feishu import decode_matrix, build_fields, FeishuError, publish
from shopee_tracker.core import Target, parse_number

TARGET={'country':'ID','affiliate_id':'1','shopee_handle':'alice','url':'https://seller.shopee.co.id/portal/web-seller-affiliate/kol_marketplace/detail?affiliate_id=1','category':'','tts_link':''}

def fixture():
    return [dict(channel=c,status='ok',target=TARGET,collected_at='2026-10-23T05:00:00+00:00',
                 period={'selected':'Last 7 Days'},page_updated_raw='23-10-2026 10:00',
                 metrics={}) for c in ('sales','live','video')]

class Feishu(unittest.TestCase):
    def test_media_can_reuse_or_refresh_the_apps_tenant_token(self):
        import os,time
        from unittest.mock import patch
        from shopee_tracker.feishu import Client
        c=Client({});c.token='cached';c.expires=time.time()+1000
        with patch.object(c,'request',return_value={'tenant_access_token':'fresh','expire':3600})as request:
            self.assertEqual(c.ensure_token(),'cached');request.assert_not_called()
            c.expires=0
            with patch.dict(os.environ,{'FEISHU_APP_ID':'fixture','FEISHU_APP_SECRET':'fixture'}):
                self.assertEqual(c.ensure_token(),'fresh')
            self.assertFalse(request.call_args.kwargs['auth'])
    def test_v3_matrix_pagination_shape_and_mismatch_detection(self):
        rows=decode_matrix({'fields':['Record Key','Country'],'record_id_list':['rec1'],'data':[['key',['ID']]],'has_more':False})
        self.assertEqual(rows,[{'record_id':'rec1','fields':{'Record Key':'key','Country':['ID']}}])
        with self.assertRaises(FeishuError): decode_matrix({'fields':['x'],'record_id_list':[],'data':[['a']]})

    def test_only_exact_live_values_enter_live_fields(self):
        results=fixture()
        results[0]['metrics']={'GMV(Rp)':parse_number('>10M','ID','GMV(Rp)')}
        results[1]['metrics']={'Livestream Session':parse_number('0','ID'),'Views':parse_number('24.293','ID'),'GPM(Rp)':parse_number('16.954','ID','GPM(Rp)')}
        fields=build_fields(results,'2026-10-23','recAlice')
        self.assertEqual(fields['Average Page Views(PV) in last 7 days'],24293)
        self.assertEqual(fields['#of live session in last 7 days'],0)
        self.assertEqual(fields['Overall GMV Raw'],'>10M')
        self.assertNotIn('Video Views',fields)
        self.assertEqual(fields['Creator'],[{'id':'recAlice'}])
        self.assertEqual(fields['Country'],['ID'])
        self.assertNotIn('Collection Notes',fields)
        self.assertNotIn('Previous Tracking Date',fields)
        results[1]['status']='no_permission'
        partial=build_fields(results,'2026-10-23','recAlice')
        self.assertEqual(partial['Record Status'],['部分成功'])
        self.assertNotIn('Average Page Views(PV) in last 7 days',partial)

    def test_timeout_requeries_before_any_retry_and_does_not_duplicate(self):
        class Server:
            def __init__(self): self.rows=[]; self.creates=0
            def records(self): return self.rows
            def create(self,fields):
                self.creates+=1
                self.rows.append({'record_id':'rec1','fields':fields})
                raise TimeoutError('response lost after server commit')
        server=Server()
        fields={'Record Key':'snapshot:ID:1:2026-10-23','Country':['ID'],'Affiliate ID':'1','Date of Tracking':'2026-10-23','Source':['自动采集'],'Period':'Last 7 Days'}
        self.assertEqual(publish(server,fields),'rec1')
        self.assertEqual(publish(server,fields),'rec1')
        self.assertEqual(server.creates,1)

    def test_conflicting_human_row_does_not_get_overwritten(self):
        class Server:
            def records(self): return [{'record_id':'human','fields':{'Record Key':'same','Source':['历史迁移']}}]
        with self.assertRaises(FeishuError): publish(Server(),{'Record Key':'same','Source':['自动采集']})

class PreviousSnapshot(unittest.TestCase):
    def test_iso_tracking_time_never_selects_the_same_day_as_previous(self):
        from shopee_tracker.feishu import previous_fields
        current={'Affiliate ID':'1','Country':['ID'],'Date of Tracking':'2026-10-23T00:00:00+08:00','Period':'Last 7 Days','#of live session in last 7 days':5}
        self.assertEqual(previous_fields([{'record_id':'current','fields':current}],current),{})

    def test_prior_window_snapshot_skips_future_dates_and_other_creator(self):
        from shopee_tracker.feishu import previous_fields
        fields={'Affiliate ID':'1','Country':['ID'],'Date of Tracking':'2026-10-23'}
        rows=[{'record_id':'a','fields':{'Affiliate ID':'1','Country':['ID'],'Date of Tracking':'2026-10-22','Period':'Last 7 Days','#of live session in last 7 days':0,'Average Page Views(PV) in last 7 days':100,'Sales revenue per 1000 PV in last 7 days':0}},
              {'record_id':'b','fields':{'Affiliate ID':'1','Country':['ID'],'Date of Tracking':'2026-11-02','Period':'Last 7 Days','Average Page Views(PV) in last 7 days':999}},
              {'record_id':'c','fields':{'Affiliate ID':'2','Country':['ID'],'Date of Tracking':'2026-10-22','Period':'Last 7 Days','Average Page Views(PV) in last 7 days':888}}]
        prev=previous_fields(rows,fields)
        self.assertEqual(prev,{'Previous Live Sessions':0,'Previous Live Views':100,'Previous Live GPM':0})
