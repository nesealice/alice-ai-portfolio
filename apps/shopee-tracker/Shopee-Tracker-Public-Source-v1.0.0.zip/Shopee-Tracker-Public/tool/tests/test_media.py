import io
import json
import struct
import tempfile
import unittest
from pathlib import Path
from shopee_tracker import media
from shopee_tracker.feishu import FeishuError


def png(width=12,height=7):
    return b'\x89PNG\r\n\x1a\n'+struct.pack('>I',13)+b'IHDR'+struct.pack('>II',width,height)+b'\x08\x02\x00\x00\x00'+b'\x00'*4


class MediaTests(unittest.TestCase):
    def test_multipart_uses_own_client_token_and_official_drive_contract(self):
        class Opener:
            def open(self,request,timeout):
                self.request=request
                return io.BytesIO(json.dumps({'code':0,'data':{'file_token':'file1'}}).encode())
        class Client:
            origin='https://open.feishu.cn'
            opener=Opener()
            token=None
            def ensure_token(self):self.token='own-app-token'
        client=Client()
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'截图.png';path.write_bytes(png())
            result=media.upload_media(client,'base123',path)
        self.assertEqual(result,{'file_token':'file1','image_width':12,'image_height':7})
        req=client.opener.request
        self.assertEqual(req.full_url,'https://open.feishu.cn/open-apis/drive/v1/medias/upload_all')
        self.assertEqual(req.get_header('Authorization'),'Bearer own-app-token')
        for value in (b'name="parent_type"\r\n\r\nbitable_file',b'name="parent_node"\r\n\r\nbase123',b'name="size"',b'name="file";',png()):
            self.assertIn(value,req.data)

    def test_rejects_oversized_or_invalid_images_before_auth(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'fake.png';path.write_bytes(b'not image')
            with self.assertRaises(FeishuError):media.upload_media(object(),'base',path)
            path.write_bytes(png())
            with self.assertRaises(FeishuError):media.upload_media(object(),'base',path,max_bytes=4)

    def test_jpeg_dimensions(self):
        data=b'\xff\xd8\xff\xc0\x00\x11\x08\x00\x07\x00\x0c'+b'\x03\x01\x11\x00\x02\x11\x00\x03\x11\x00\xff\xd9'
        self.assertEqual(media.image_dimensions(data),(12,7,'image/jpeg'))
