import unittest,tempfile,json,zipfile
from pathlib import Path
from unittest.mock import patch
from dataclasses import asdict
from xml.etree import ElementTree as ET
from shopee_tracker.core import Store,Target,parse_number

T=Target('ID','123','示例达人','=unused',[])
def capture(run,date='2026-10-23',views='0',sessions='2'):
 t=asdict(T);t['url']='https://seller.shopee.co.id/portal/web-seller-affiliate/kol_marketplace/detail?affiliate_id=123'
 return dict(run_id=run,channel='live',status='ok',target=t,collected_at=date+'T05:00:00+00:00',period={'selected':'Last 7 Days'},screenshot='',metrics={'Views':parse_number(views,'ID'),'Livestream Session':parse_number(sessions,'ID'),'GPM(Rp)':parse_number('1JT-2JT','ID')})
class PublicOutput(unittest.TestCase):
 def test_excel_retains_zero_ranges_unicode_and_idempotent_rows(self):
  from shopee_tracker.output import write_local
  with tempfile.TemporaryDirectory()as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');r=s.new_run([T],'2026-10-23');s.save(r,T,'live',capture(r));c=d/'base-config.json';c.write_text('{"output":"excel"}')
   write_local(s,r,c);write_local(s,r,c)
   self.assertEqual(s.db.execute('select count(*) from writebacks').fetchone()[0],1)
   with zipfile.ZipFile(d/'exports/tracking.xlsx')as z:
    xml=z.read('xl/worksheets/sheet1.xml').decode();ET.fromstring(xml)
    self.assertIn('示例达人',xml);self.assertIn('1JT-2JT',xml);self.assertIn('<v>0</v>',xml)
    self.assertEqual(xml.count('<row '),2)
   s.close()
 def test_diff_is_prior_rolling_snapshot_and_missing_is_blank(self):
  from shopee_tracker.output import write_local,local_rows
  with tempfile.TemporaryDirectory()as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');c=d/'base-config.json';c.write_text('{"output":"excel"}')
   for date,v in [('2026-10-22','10'),('2026-10-23','15')]:
    r=s.new_run([T],date);s.save(r,T,'live',capture(r,date,v));write_local(s,r,c)
   rows=local_rows(s);self.assertIsNone(rows[0]['Views change']);self.assertEqual(rows[1]['Views change'],5)
   self.assertIsNone(rows[1]['GPM change']);s.close()
 def test_failed_workbook_write_never_marks_success(self):
  from shopee_tracker.output import write_local
  with tempfile.TemporaryDirectory()as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');r=s.new_run([T],'2026-10-23');s.save(r,T,'live',capture(r));c=d/'base-config.json';c.write_text('{"output":"excel"}')
   with patch('shopee_tracker.output.write_xlsx',side_effect=OSError('disk full')):
    with self.assertRaises(OSError):write_local(s,r,c)
   self.assertEqual(s.db.execute('select count(*) from writebacks').fetchone()[0],0);s.close()
 def test_xlsx_strings_are_never_formulas(self):
  from shopee_tracker.output import write_xlsx
  with tempfile.TemporaryDirectory()as tmp:
   p=Path(tmp)/'safe.xlsx';write_xlsx(p,[{'Handle':'=HYPERLINK("bad")'}],['Handle'])
   with zipfile.ZipFile(p)as z:
    xml=z.read('xl/worksheets/sheet1.xml');self.assertNotIn(b'<f',xml);self.assertIn(b'inlineStr',xml)
class PublicConfig(unittest.TestCase):
 def test_no_targets_blocks_and_one_authorized_id_target_allowed(self):
  from shopee_tracker.config import configured_targets
  with tempfile.TemporaryDirectory()as tmp:
   d=Path(tmp);(d/'targets.csv').write_text('country,affiliate_id,shopee_handle,url\n')
   with self.assertRaisesRegex(ValueError,'达人'):configured_targets(d)
   (d/'targets.csv').write_text('country,affiliate_id,shopee_handle,url\nID,123,demo,https://seller.shopee.co.id/portal/web-seller-affiliate/kol_marketplace/detail?affiliate_id=123\n')
   self.assertEqual(len(configured_targets(d)),1)

class PublicPipeline(unittest.TestCase):
 def test_default_daily_is_excel_only_and_same_day_target_change_is_blocked(self):
  from shopee_tracker.cli import main
  from shopee_tracker.status import mark,read_dashboard
  from shopee_tracker.config import configured_targets
  with tempfile.TemporaryDirectory()as tmp:
   d=Path(tmp);csv='country,affiliate_id,shopee_handle,url\nID,123,demo,https://seller.shopee.co.id/portal/web-seller-affiliate/kol_marketplace/detail?affiliate_id=123\n';(d/'targets.csv').write_text(csv)
   def collect(data,store,run,interactive,on_complete):
    t=store.run(run)['targets'][0]
    for channel in ('sales','live','video'):
     row=capture(run);row.update(channel=channel,screenshot=str(d/'proof.png'));store.save(run,t,channel,row)
    mark(store,run,t,'extraction','done');on_complete(t)
   with patch('shopee_tracker.cli.collect',side_effect=collect),patch('shopee_tracker.feishu.Client')as cloud,patch('shopee_tracker.cli.today',return_value='2026-10-23'):
    self.assertEqual(main(['--data-dir',str(d),'daily']),0);cloud.assert_not_called()
    self.assertTrue((d/'exports/tracking.xlsx').exists());self.assertEqual(read_dashboard(d)['summary']['written'],1)
    (d/'targets.csv').write_text(csv.replace(',demo,',',renamed,'))
    self.assertEqual(main(['--data-dir',str(d),'daily']),1)

class DestinationState(unittest.TestCase):
 def test_failed_rewrite_clears_old_success_and_changing_target_requires_new_receipt(self):
  from shopee_tracker.output import write_local
  from shopee_tracker.status import read_dashboard
  with tempfile.TemporaryDirectory()as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');r=s.new_run([T],'2026-10-23');s.save(r,T,'live',capture(r));c=d/'base-config.json';c.write_text('{"output":"excel"}');write_local(s,r,c)
   self.assertEqual(read_dashboard(d)['summary']['written'],1)
   c.write_text('{"output":"feishu","base_token":"example","snapshot_table_id":"example"}')
   self.assertEqual(read_dashboard(d)['summary']['written'],0)
   c.write_text('{"output":"excel"}')
   with patch('shopee_tracker.output.write_xlsx',side_effect=OSError('disk full')):
    with self.assertRaises(OSError):write_local(s,r,c)
   self.assertEqual(read_dashboard(d)['summary']['written'],0);self.assertEqual(read_dashboard(d)['summary']['write_failed'],1);s.close()

class ExcelRanges(unittest.TestCase):
 def test_views_range_preserves_raw_status_without_numeric_diff(self):
  from shopee_tracker.output import write_local
  with tempfile.TemporaryDirectory()as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');r=s.new_run([T],'2026-10-23');s.save(r,T,'live',capture(r,views='1RB-2RB'));c=d/'base-config.json';c.write_text('{"output":"excel"}');write_local(s,r,c)
   with zipfile.ZipFile(d/'exports/tracking.xlsx')as z:
    xml=z.read('xl/worksheets/sheet1.xml').decode();self.assertIn('1RB-2RB',xml);self.assertIn('range',xml)
   s.close()
