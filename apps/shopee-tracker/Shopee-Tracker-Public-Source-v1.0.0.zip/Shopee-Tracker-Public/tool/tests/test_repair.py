import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from shopee_tracker.core import Store,Target,parse_number
from shopee_tracker.feishu import build_fields,publish,FeishuError

T=Target('ID','123','alice','https://seller.shopee.co.id/portal/web-seller-affiliate/kol_marketplace/detail?affiliate_id=123',[])
def payload(channel='live',run='r'):
 from dataclasses import asdict
 return dict(channel=channel,status='ok',target=asdict(T),run_id=run,collected_at='2026-10-23T05:00:00+00:00',period={'selected':'Last 7 Days'},metrics={'Views':parse_number('0','ID')})
class PartialRecords(unittest.TestCase):
 def test_base_normalized_blank_text_is_verified_without_duplicate_create(self):
  class Server:
   def __init__(self):self.rows=[];self.creates=0
   def records(self):return self.rows
   def create(self,f):
    self.creates+=1;self.rows.append({'record_id':'rec1','fields':{k:None if v=='' else v for k,v in f.items()}})
  s=Server();f=build_fields([payload()],'2026-10-23','recA')
  self.assertEqual(publish(s,f),'rec1');self.assertEqual(publish(s,f),'rec1');self.assertEqual(s.creates,1)
 def test_write_rejection_retains_actionable_scope_error(self):
  class Server:
   def records(self):return []
   def create(self,f):raise FeishuError('Access denied: base:record:create')
  with self.assertRaisesRegex(FeishuError,'base:record:create'):
   publish(Server(),build_fields([payload()],'2026-10-23','recA'))
 def test_verified_live_is_written_when_video_fails(self):
  rows=[payload(),dict(payload('video'),status='unsupported_dom',error='layout changed')]
  f=build_fields(rows,'2026-10-23','recA')
  self.assertEqual(f['Record Status'],['部分成功'])
  self.assertEqual(f['Average Page Views(PV) in last 7 days'],0)
  self.assertNotIn('Video Views',f)
 def test_zero_success_cannot_create_empty_record(self):
  with self.assertRaises(FeishuError):build_fields([dict(payload(),status='collection_failed')],'2026-10-23','recA')
 def test_resume_can_add_new_channel_but_not_change_successful_channel(self):
  class Server:
   def __init__(self):self.rows=[];self.updates=0
   def records(self):return self.rows
   def create(self,f):self.rows.append({'record_id':'rec1','fields':dict(f)})
   def update(self,rid,f):self.updates+=1;self.rows[0]['fields'].update(f)
  s=Server();first=build_fields([payload()],'2026-10-23','recA');publish(s,first)
  second=build_fields([payload(),payload('video')],'2026-10-23','recA')
  self.assertEqual(publish(s,second),'rec1');self.assertEqual(s.updates,1)
  self.assertEqual(publish(s,second),'rec1');self.assertEqual(s.updates,1)
  changed=payload();changed['metrics']={'Views':parse_number('10','ID')}
  with self.assertRaises(FeishuError):publish(s,build_fields([changed,payload('video')],'2026-10-23','recA'))
class Dashboard(unittest.TestCase):
 def test_old_failed_database_is_readable_in_chinese_and_has_no_success(self):
  from shopee_tracker.status import read_dashboard
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');r=s.new_run([T],'2026-10-23')
   for c in ('sales','live','video'):s.save(r,T,c,{'status':'unsupported_dom','error':'Cannot identify single closed period dropdown'})
   s.close();view=read_dashboard(d)
   self.assertEqual(view['summary']['extracted'],0);self.assertEqual(view['summary']['written'],0)
   self.assertEqual(view['creators'][0]['extraction'],'提取失败')
   self.assertEqual(view['creators'][0]['writeback'],'无需写入')
   self.assertIn('页面',view['creators'][0]['reason'])
class AutoPipeline(unittest.TestCase):
 def test_resume_clears_interrupted_running_markers_before_collection(self):
  from shopee_tracker.cli import run_pipeline
  from shopee_tracker.status import mark
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');run=s.new_run([T],'2026-10-23')
   mark(s,run,T,'extraction','running');mark(s,run,T,'writeback','running')
   def inspect(data,store,run,interactive,on_complete):
    self.assertEqual(store.db.execute("SELECT count(*) FROM progress WHERE run=? AND state='running'",(run,)).fetchone()[0],0)
   with patch('shopee_tracker.cli.collect',side_effect=inspect):run_pipeline(d,s,run,d/'base-config.json')
   s.close()
 def test_completion_calls_writeback_without_extra_user_action(self):
  from shopee_tracker.cli import run_pipeline
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');run=s.new_run([T],'2026-10-23')
   def fake_collect(data,store,run,interactive,on_complete):
    store.save(run,T,'live',payload())
    on_complete(T)
   with patch('shopee_tracker.cli.collect',side_effect=fake_collect),patch('shopee_tracker.output.writeback',return_value=[]) as write:
    run_pipeline(d,s,run,d/'base-config.json')
    self.assertEqual(write.call_count,1)
    self.assertEqual(write.call_args.kwargs['only_targets'],[T])
   s.close()
class ReadyPage(unittest.TestCase):
 def test_base_access_error_explains_table_application_authorization(self):
  from shopee_tracker.status import friendly_error
  self.assertIn('添加应用',friendly_error("Feishu HTTP error 403 (91403: you don't have permission); endpoint=Base"))
 def test_verification_failure_is_recognized_not_called_unknown_layout(self):
  from shopee_tracker.browser import detect_blocker
  self.assertEqual(detect_blocker('https://seller.shopee.co.id/verify',"Please Try Again Later\nVerification can't be completed. Please try again after a few minutes."),'verification_unavailable')
class StaleCloudStatus(unittest.TestCase):
 def test_old_subset_success_never_masks_new_unwritten_channel(self):
  from shopee_tracker.status import read_dashboard,mark
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);s=Store(d/'state.sqlite');run=s.new_run([T],'2026-10-23');s.save(run,T,'live',payload(run=run))
   f=build_fields(s.results(run),'2026-10-23','recA')
   with s.db:s.db.execute('INSERT INTO writebacks VALUES(?,?,?)',(f['Record Key'],'rec1',json.dumps(f)))
   mark(s,run,T,'writeback','success','', 'rec1')
   s.save(run,T,'video',payload('video',run))
   self.assertNotEqual(read_dashboard(d)['creators'][0]['writeback'],'写入成功')
   s.close()
class RetryFailureMetadata(unittest.TestCase):
 def test_failed_channel_timestamp_changes_do_not_conflict_with_verified_data(self):
  class Server:
   def __init__(self):self.rows=[]
   def records(self):return self.rows
   def create(self,f):self.rows.append({'record_id':'rec1','fields':dict(f)})
   def update(self,rid,f):self.rows[0]['fields'].update(f)
  server=Server();good=payload();failed=dict(payload('video'),status='collection_failed',error='loading_timeout')
  publish(server,build_fields([good,failed],'2026-10-23','recA'))
  failed['collected_at']='2026-10-23T06:00:00+00:00'
  self.assertEqual(publish(server,build_fields([good,failed],'2026-10-23','recA')),'rec1')

class MidChannelBlock(unittest.TestCase):
 def test_resume_retries_pending_creator_before_rechecking_completed_creators(self):
  from shopee_tracker.cli import collect
  from unittest.mock import Mock,MagicMock
  with tempfile.TemporaryDirectory()as tmp:
   data=Path(tmp);s=Store(data/'state.sqlite');second=Target('ID','456','bob',T.url.replace('123','456'),[])
   run=s.new_run([T,second],'2026-10-23')
   for c in ('sales','live','video'):s.save(run,T,c,payload(c,run))
   page=Mock();page.is_closed.return_value=False;session=Mock();session.pages=[page];adapter=Mock();adapter.read.side_effect=[payload(c,run)for c in ('sales','live','video')];completed=[]
   with patch('shopee_tracker.cli.today',return_value='2026-10-23'),patch('shopee_tracker.cli.browser_session',return_value=MagicMock()),patch('shopee_tracker.browser.launch',return_value=session),patch('shopee_tracker.browser.VisibleAdapter',return_value=adapter):
    collect(data,s,run,False,on_complete=completed.append)
   self.assertEqual(completed,[second,T]);s.close()
 def test_verified_sales_is_saved_and_further_creators_are_paused(self):
  from shopee_tracker.cli import collect
  from shopee_tracker.core import UnsupportedDOM
  from unittest.mock import Mock,MagicMock
  with tempfile.TemporaryDirectory() as tmp:
   data=Path(tmp);s=Store(data/'state.sqlite');second=Target('ID','456','bob',T.url.replace('123','456'),[])
   run=s.new_run([T,second],'2026-10-23');session=Mock();page=Mock();page.is_closed.return_value=False;session.pages=[page]
   manager=MagicMock();adapter=Mock();adapter.read.side_effect=[payload('sales'),UnsupportedDOM('verification_unavailable')];completed=[]
   with patch('shopee_tracker.cli.today',return_value='2026-10-23'),patch('shopee_tracker.cli.browser_session',return_value=manager),patch('shopee_tracker.browser.launch',return_value=session),patch('shopee_tracker.browser.VisibleAdapter',return_value=adapter):
    collect(data,s,run,False,on_complete=completed.append)
   self.assertEqual(page.goto.call_count,1);self.assertEqual(completed,[T]);self.assertEqual(len(s.results(run)),3)
   states={r['channel']:r['status']for r in s.results(run)}
   self.assertEqual(states,{'sales':'ok','live':'verification_unavailable','video':'verification_unavailable'})
   session.close.assert_called_once();s.close()
class ActualDisplayValues(unittest.TestCase):
 def test_double_dash_is_missing_not_zero_or_error(self):
  from shopee_tracker.core import extract_metrics
  r=extract_metrics('Clicks\n<1RB\nROI\n--','ID','sales')
  self.assertEqual(r['ROI']['status'],'missing');self.assertIsNone(r['ROI']['value'])
 def test_video_post_is_a_video_count_label(self):
  from shopee_tracker.core import extract_metrics
  m=extract_metrics('Video Post\n0\nViews\n0','ID','video')
  f=build_fields([dict(payload('video'),metrics=m)],'2026-10-23','recA')
  self.assertEqual(f['Video Count'],0)
class CompactRanges(unittest.TestCase):
 def test_unspaced_hyphen_ranges_from_real_sales_cards(self):
  n=parse_number('2JT-10JT','ID','GMV(Rp)');self.assertEqual(n['status'],'range');self.assertEqual(n['lower'],'2000000');self.assertEqual(n['upper'],'10000000')
  self.assertEqual(parse_number('100-200','ID')['upper'],'200')

class RequiredProofCompletion(unittest.TestCase):
 def test_numeric_success_is_incomplete_until_all_current_proofs_are_verified(self):
  from shopee_tracker.cli import pipeline_exit
  from shopee_tracker.status import mark
  with tempfile.TemporaryDirectory()as tmp:
   s=Store(Path(tmp)/'db.sqlite');run=s.new_run([T],'2026-10-23');paths=[]
   for c in ('sales','live','video'):
    p=dict(payload(c,run),screenshot='/tmp/'+c+'.png');paths.append(p['screenshot']);s.save(run,T,c,p)
   mark(s,run,T,'writeback','success')
   self.assertEqual(pipeline_exit(s,run,[T]),2)
   s.db.execute('CREATE TABLE attachment_uploads(snapshot_key TEXT PRIMARY KEY,state TEXT,details TEXT)')
   key='snapshot:ID:123:2026-10-23'
   with s.db:s.db.execute('INSERT INTO attachment_uploads VALUES(?,?,?)',(key,'uploaded_verified',json.dumps({'paths':paths[:2]})))
   self.assertEqual(pipeline_exit(s,run,[T]),2)
   with s.db:s.db.execute('UPDATE attachment_uploads SET details=?',(json.dumps({'paths':paths}),))
   self.assertEqual(pipeline_exit(s,run,[T]),0);s.close()
 def test_rejected_proof_has_separate_visible_failure_reason(self):
  from shopee_tracker.status import read_dashboard
  with tempfile.TemporaryDirectory()as tmp:
   data=Path(tmp);s=Store(data/'state.sqlite');run=s.new_run([T],'2026-10-23');s.save(run,T,'live',dict(payload(run=run),screenshot='/tmp/live.png'))
   s.db.execute('CREATE TABLE attachment_uploads(snapshot_key TEXT PRIMARY KEY,state TEXT,details TEXT)')
   with s.db:s.db.execute('INSERT INTO attachment_uploads VALUES(?,?,?)',('snapshot:ID:123:2026-10-23','upload_rejected',json.dumps({'paths':['/tmp/live.png'],'notes':'docs:document.media:upload permission missing'})))
   row=read_dashboard(data)['creators'][0];self.assertIn('上传失败',row['cloud_proof']);self.assertIn('权限',row['reason']);s.close()

class LoginIdentity(unittest.TestCase):
 def test_login_accepts_verified_official_header_after_creator_rename(self):
  from unittest.mock import Mock
  from shopee_tracker.cli import wait_for_manual
  page=Mock();page.url=T.url;page.is_closed.return_value=False
  page.locator.return_value.inner_text.return_value='new_handle\nSales Metrics'
  with patch('shopee_tracker.browser.VisibleAdapter.verify_target',return_value={'handle_changed':True})as check,patch('time.monotonic',side_effect=[0,0,2]):
   wait_for_manual(page,T,seconds=1)
   check.assert_called_once_with(T,'new_handle\nSales Metrics')
