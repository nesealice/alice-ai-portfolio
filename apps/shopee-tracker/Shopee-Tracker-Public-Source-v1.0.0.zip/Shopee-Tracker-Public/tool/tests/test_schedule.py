import plistlib
import tempfile
import unittest
from pathlib import Path
from shopee_tracker.schedule import write_schedule

class Schedule(unittest.TestCase):
    def test_plist_uses_argument_array_and_rejects_invalid_time(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=Path(tmp)/'folder with spaces';data.mkdir()
            path=write_schedule(data,'09:15',None)
            plist=plistlib.loads(Path(path).read_bytes())
            self.assertEqual(plist['StartCalendarInterval'],{'Hour':9,'Minute':15})
            self.assertEqual(plist['ProgramArguments'][-1],'daily')
            self.assertIn(str(data),plist['ProgramArguments'])
            self.assertFalse(plist['RunAtLoad'])
            with self.assertRaises(ValueError): write_schedule(data,'25:99',None)

    def test_frozen_schedule_uses_persistent_working_directory(self):
        from unittest.mock import patch
        import shopee_tracker.schedule as schedule
        with tempfile.TemporaryDirectory() as tmp, patch.object(schedule.sys,'frozen',True,create=True):
            data=Path(tmp)
            path=write_schedule(data,'09:15',None)
            plist=plistlib.loads(Path(path).read_bytes())
            self.assertEqual(plist['WorkingDirectory'],str(data))
            self.assertEqual(plist['ProgramArguments'][1],'--cli')

class ResidentSchedule(unittest.TestCase):
    def test_due_once_after_wake_and_restart(self):
        from datetime import datetime
        from shopee_tracker.schedule import DailySchedule
        with tempfile.TemporaryDirectory() as tmp:
            schedule=DailySchedule(Path(tmp))
            self.assertFalse(schedule.claim(datetime(2026,10,23,9,59)))
            self.assertFalse(schedule.claim(datetime(2026,10,23,10,1),busy=True))
            self.assertTrue(schedule.claim(datetime(2026,10,23,14,30)))
            self.assertFalse(schedule.claim(datetime(2026,10,23,14,31)))
            schedule=DailySchedule(Path(tmp))
            self.assertFalse(schedule.claim(datetime(2026,10,23,23,59)))
            self.assertFalse(schedule.claim(datetime(2026,10,24,9,59)))
            self.assertTrue(schedule.claim(datetime(2026,10,24,10,0)))

    def test_manual_collection_suppresses_duplicate_and_auth_persists(self):
        from datetime import datetime
        from shopee_tracker.schedule import DailySchedule
        with tempfile.TemporaryDirectory() as tmp:
            schedule=DailySchedule(Path(tmp))
            schedule.record_collection(datetime(2026,10,23,9,0))
            self.assertFalse(schedule.claim(datetime(2026,10,23,10,0)))
            schedule.result('login_required')
            snapshot=DailySchedule(Path(tmp)).snapshot(datetime(2026,10,23,15,0))
            self.assertTrue(snapshot['enabled']);self.assertTrue(snapshot['needs_auth'])
            self.assertEqual(snapshot['next_run'],'2026-10-24T10:00:00')
            schedule.result('');self.assertFalse(schedule.snapshot()['needs_auth'])

    def test_clock_rollback_does_not_recollect_old_date(self):
        from datetime import datetime
        from shopee_tracker.schedule import DailySchedule
        with tempfile.TemporaryDirectory() as tmp:
            schedule=DailySchedule(Path(tmp))
            self.assertTrue(schedule.claim(datetime(2026,10,24,10,0)))
            self.assertFalse(schedule.claim(datetime(2026,10,23,11,0)))

    def test_login_agent_is_resident_without_opening_ui(self):
        from shopee_tracker.schedule import write_background_agent
        with tempfile.TemporaryDirectory() as tmp:
            data=Path(tmp)/'data';agents=Path(tmp)/'LaunchAgents'
            executable=Path('/Applications/Shopee Tracker.app/Contents/MacOS/Shopee Tracker')
            path=write_background_agent(data,executable,agents)
            content=Path(path).read_bytes();plist=plistlib.loads(content)
            self.assertEqual(plist['ProgramArguments'],[str(executable),'--background'])
            self.assertTrue(plist['RunAtLoad']);self.assertTrue(plist['KeepAlive'])
            self.assertNotIn('StartCalendarInterval',plist)
            self.assertEqual(plist['EnvironmentVariables']['SHOPEE_TRACKER_DATA'],str(data.resolve()))
            self.assertEqual(write_background_agent(data,executable,agents),path)
            self.assertEqual(Path(path).read_bytes(),content)

    def test_installer_bootstraps_once_then_leaves_loaded_service_running(self):
        import subprocess
        from unittest.mock import Mock
        from shopee_tracker.schedule import install_background_agent
        with tempfile.TemporaryDirectory() as tmp:
            data=Path(tmp)/'data';agents=Path(tmp)/'agents'
            runner=Mock(side_effect=[subprocess.CompletedProcess([],113),subprocess.CompletedProcess([],0)])
            install_background_agent(data,Path(tmp)/'app',agents,runner)
            self.assertEqual([call.args[0][1] for call in runner.call_args_list],['print','bootstrap'])
            self.assertEqual((data/'background.log').stat().st_mode&0o777,0o600)
            self.assertEqual((agents/'com.local.shopeetracker.public.background.plist').stat().st_mode&0o777,0o600)


    def test_startup_indicator_matches_executable_and_data_directory(self):
        from shopee_tracker.schedule import background_agent_installed,write_background_agent
        with tempfile.TemporaryDirectory() as tmp:
            data=Path(tmp)/'data';agents=Path(tmp)/'agents';exe=Path(tmp)/'app'
            self.assertFalse(background_agent_installed(data,exe,agents))
            write_background_agent(data,exe,agents)
            self.assertTrue(background_agent_installed(data,exe,agents))
            self.assertFalse(background_agent_installed(data,Path(tmp)/'other-app',agents))
            self.assertFalse(background_agent_installed(Path(tmp)/'other-data',exe,agents))

    def test_feishu_permission_block_is_also_flagged_for_attention(self):
        from shopee_tracker.schedule import DailySchedule
        with tempfile.TemporaryDirectory()as tmp:
            schedule=DailySchedule(Path(tmp));schedule.result('飞书截图上传权限未生效，请管理员开通媒体上传权限')
            self.assertTrue(schedule.snapshot()['needs_auth'])
